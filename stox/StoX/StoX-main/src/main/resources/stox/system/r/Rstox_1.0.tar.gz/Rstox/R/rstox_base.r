#*********************************************
#*********************************************
#' Create or open a StoX project
#'
#' \code{createProject} creates a new project from acoustic and biotic xml files. \cr \cr
#' \code{openProject} opens a StoX project with the given project name. \cr \cr
#'
#' @param projectName The name of the project. In getProjectDir() projectName can also be a baseline object.
#' @param projectRoot Folder parent to the project folder.
#' @param template template to model.
#' \describe{
#'  \item{"AcousticAbundanceTransect"}{Acoustic bundance model based on strata/transects - using acoustic/biotic}
#'  \item{"StationLengthDistTemplate"}{Station length distribution - using only biotic}
#'  \item{"SweptAreaTemplate"}{Swept area template - using only biotic}
#'  \item{"SplitNASC"}{Split NASC - using acoustic/biotic}
#' }
#' @param acoustic the path(s) to acoustic data (either a directory holding the files or a vector of the paths to the files).
#' @param biotic the path(s) to biological data (either a directory holding the files or a vector of the paths to the files).
#' @param ow specifies whether to ovewrite existing project: If TRUE, overwrite; if FALSE, do not overwrite; if NULL (default), aks the user to confitm overwriting.
#'
#' @examples
#' \dontrun{
#' createProject("Test_Rstox", acoustic=system.file("extdata", "Test_Rstox", package="Rstox"), ow=FALSE)}
#'
#' @return A project object
#' 
#' @importFrom rJava J
#' @export
#' @rdname createProject
#' 
createProject <- function(projectName, projectRoot=NULL, template="StationLengthDistTemplate", acoustic=NULL, biotic=NULL, ow=NULL) {
	.Rstox.init()
  if(length(projectRoot) == 0){
		projectRoot <- J("no.imr.stox.functions.utils.ProjectUtils")$getSystemProjectRoot()
  }
	projectdir <- file.path(projectRoot, projectName)
	#inputdir <- file.path(projectdir, "input")
  if(file.exists(projectdir)){
    if(length(ow)==0){
      ans = readline("Project already exists. Overwrite? (y/n)")
      if(ans!="y"){
        cat("Not overwriting", file.path(projectRoot,projectName))
        return()
      }
		}
    else if(!ow){
      cat("Not overwriting", file.path(projectRoot,projectName))
      return()
    }
  }
  template <- J("no.imr.stox.factory.Factory")$TEMPLATE_ACOUSTICABUNDANCETRANSECT
  pr <- J("no.imr.stox.factory.FactoryUtil")$acquireProject(projectRoot, projectName, template)
  
  # Move the files separately
  moveProjectPart <- function(x){
    if(is.character(x) && isTRUE(file.info(x)$isdir) && any(c("input", "output", "process") %in% list.files(x))){
      filePaths <- list.files(x, full.name=TRUE, recursive=TRUE)
      newFilePaths <- file.path(projectdir, list.files(x, recursive=TRUE))
      for(i in seq_along(filePaths)){
      if(file.exists(filePaths[i]))
        file.copy(filePaths[i], newFilePaths[i], overwrite=TRUE)
      }
      return(TRUE)
    }
  else{
    return(TRUE)
    }
  }
  if(moveProjectPart(acoustic)){
    return(projectdir)
  }
  if(moveProjectPart(biotic)){
    return(projectdir)
  }
  
  # Copy acoustic and biotic files to the project directory:
  bioticDir <- file.path(projectdir, "input", "biotic")
  acousticDir <- file.path(projectdir, "input", "acoustic")
  if(length(biotic)==1 && isTRUE(file.info(biotic)$isdir)){
    biotic = list.files(biotic, full.names=TRUE)
  }
  if(length(acoustic)==1 && isTRUE(file.info(acoustic)$isdir)){
    acoustic = list.files(acoustic, full.names=TRUE)
  }
  if(length(biotic)>0){
    file.copy(biotic, bioticDir)
  }
  if(length(acoustic)>0){
    file.copy(acoustic, acousticDir)
  }
  
  # Modify process to point to xml file
  bioticFiles <- list.files(bioticDir, full.names=TRUE)
  acousticFiles <- list.files(acousticDir, full.names=TRUE)
  for(i in seq_along(bioticFiles)) pr$getBaseline()$findProcessByFunction("ReadBioticXML")$setParameterValue(paste0("FileName",i), bioticFiles[i])
  for(i in seq_along(acousticFiles)) pr$getBaseline()$findProcessByFunction("ReadAcousticXML")$setParameterValue(paste0("FileName",i), acousticFiles[i])

  # Save and return the project:
  pr$save()
  pr
}
#' 
#' @importFrom rJava J
#' @export
#' @rdname createProject
#' 
openProject <- function(projectName){
  # Allow for a baseline object as input:
  #if(any(is(projectName)=="jobjRef")){
  #  projectName <- projectName$getProject()$getProjectName()
  #}
	projectName <- getProjectName(projectName)
  # Check for the existence of the project object in the RstoxEnv evnironment:
  if(projectName %in% ls(get(getProjectEnvName()))){
    project <- get(projectName, envir=get(getProjectEnvName()))
  }
  # Otherwise, open the project, generate the project object, and save it to the RstoxEnv evnironment:
  else{
    if(!is.character(projectName)){
      warning("projectName must be a character string naming the project. Was a baseline object used?")
    }
    # Reference to "no/imr/stox/model/Project" requires  .Rstox.init():
    .Rstox.init()
    project <- .jnew("no/imr/stox/model/Project")
    # Set working project
    project$setProjectName(projectName)
		if(file.exists(file.path(project$getRootFolder(), projectName))){
	    project$openProject()
	    # Create an environment for the project:
	    projectEnv = getProjectEnvName(projectName)
	    if(!exists(projectEnv)){
	      assign(projectEnv, new.env(), envir=.GlobalEnv)
	    }
	    # Save the project object to the RstoxEnv environment:
	    assign(projectName, project, envir=get(getProjectEnvName()))
		}
    else{
    	project <- NULL
    }
  }
  # Return the project object:
  project
}
#' 
#' @export
#' @rdname createProject
#' 
saveProject <- function(projectName){
  openProject(projectName)$save()
    ## If a project is given, use it directly:
    #if(any(is(projectName)=="jobjRef") && projectName$getClass()$toString()=="class no/imr/stox/model/Project"){
    #  projectName$save()
    #}
    ## Allow for a baseline object as input:
    #if(any(is(projectName)=="jobjRef") && projectName$getClass()$toString()=="class no/imr/stox/model/Model"){
    #  projectName$getProject()$save()
    #}
  #else{
  #  get(projectName, envir=get(getProjectEnvName()))$save()
  #}
}
#' 
#' @export
#' @rdname createProject
#' 
pointToStoXFiles <- function(projectName){
  pointToStoXFilesSingle <- function(data_type, project, projectdir){
	dir <- file.path(projectdir, "input", data_type)
    files <- list.files(dir, full.names=TRUE)
    fun <- paste0("Read", toupper(substr(data_type, 1, 1)), substring(data_type, 2), "XML")
    for(i in seq_along(files)){
      proc <- project$getBaseline()$findProcessByFunction(fun)
      if(length(names(proc))){
        proc$setParameterValue(paste0("FileName",i), files[i])
      }
    }
    files
  }
  project <- openProject(projectName)
  projectdir <- project$getProjectFolder()
  StoX_data_types <- get("StoX_data_types", envir=get("RstoxEnv"))
  out <- lapply(StoX_data_types, pointToStoXFilesSingle, project, projectdir)
  project$save()
  out
}


#*********************************************
#*********************************************
#' Run (or get without running, nostly used internal in Rstox) a baseline model created by StoX
#' 
#' \code{runBaseline} runs a baseline model created by StoX, and includes possibilities to specify start and end process and to override parameters in the baseline model. It is also possible to return a list of the existing processes with parameter values.
#' \code{getBaseline} returns the name a reference to a baseline model that may have been run in JAVA memory already.
#' 
#' @param projectName The name of an existing StoX project.
#' @param startProcess The name or number of the start process in the list of processes in the model (use info=TRUE to return a list of the processes). The use of startProcess and endProcess requres that either no processes in the given range of processes depends on processes outside of the range, or that a baseline object is given in the input.
#' @param endProcess The name or number of the end process in the list of processes in the model (use info=TRUE to return a list of the processes).
#' @param rewrite Logical; if TRUE the existing file named "project.xml", which conatins all specifications of the project (including parameter values and strata definitions), will be overwitten by with the possible new settings (see description of "...").
#' @param save Logical; if TRUE changes to the project specified in "..." are saved to the project.xml file. Default is FALSE, and one should be aware that changes are non-reversable.
#' @param parList List of parameters values overriding existing parameter values. These are specified as processName = list(parameter = value), for example AcousticDensity = list(a = -70, m = 10), BioStationWeighting = list(WeightingMethod = "NASC", a = -70, m = 10). Numeric parameters must be given as numeric, string parameters as string, and logical parameters (given as strings "true"/"false" in StoX) can be given as logical TRUE/FALSE.
#' @param ... Same as parList, but can be specified separately (not in a list but as separate inputs).
#' @param prNames The names of the processes from which to return data. If set to NULL, all processes are requested.
#' @param prData The names of the processes data variables (information stored in the process.xml file) from which to return data. If set to NULL, all processes data are requested.
#' @param check.names Logical; if TRUE (default), check whether the process names 'prNames' or process data variable names 'prData' exist (time consuming).
#' @param level The level of tables for some datatypes like FishStation, which contains different levels, i.e., 1 for fishstation, 2 for sample and 3 for individuals. The default level=NULL returns all levels.
#'
#' @return A reference to the StoX Java baseline object
#'
#' @examples
#' \dontrun{
#' createProject("Test_Rstox", files=system.file("extdata", "Test_Rstox", package="Rstox"), ow=NULL)
#' system.time(baseline <- runBaseline("Test_Rstox"))
#' system.time(baselineInfo <- runBaseline("Test_Rstox", info=TRUE))
#' baselineInfo
#' system.time(baseline <- runBaseline("Test_Rstox", AcousticDensity = list(a = -70, m = 10), BioStationWeighting = list(WeightingMethod = "NASC", Radius=100, a = -70, m = 10)))
#'
#' @export
#' @rdname runBaseline
#'
runBaseline <- function(projectName, startProcess=1, endProcess=Inf, save=FALSE, parList=list(), ...){
	# Open the project (avoiding generating multiple identical project which demands memory in Jaca):
  project <- openProject(projectName)
  baseline <- project$getBaseline()
  baseline$setBreakable(.jBoolean(FALSE))
  baseline$setExportCSV(.jBoolean(FALSE))
	numProcesses <- baseline$getProcessList()$size()
	
	# Set start and end for the baseline run:
  if(!is.numeric(startProcess)){
    startProcess <- baseline$getProcessList()$indexOf(baseline$findProcess(startProcess)) + 1
  }
  if(!is.numeric(endProcess)){
    endProcess <- baseline$getProcessList()$indexOf(baseline$findProcess(endProcess)) + 1
  }
  startProcess = max(startProcess, 1)
  endProcess = min(endProcess, numProcesses)
  
  # Remove processes that saves the project.xml file, which is assumed to ALWAYS be the last process. Please ask Åsmund to set this as a requirement in StoX: 
  if(!save){
    endProcess <- min(endProcess, numProcesses - 1)
  }
 
	# Override parameters in the baseline:
  originalParameters <- overrideBaselineParameters(baseline, save=save, parList=parList, ...)
  # Run the baseline:
	baseline$run(.jInt(startProcess), .jInt(endProcess), .jBoolean(FALSE))
  # Return to original parameter values:
  overrideBaselineParameters(baseline, save=FALSE, parList=originalParameters)
	
	##### FAILED ATTEMPT TO SAVE THE BASELINE OBJECT TO THE RSTOX-ENVIRONMENT. THIS CAUSED CONFUSION ABOUT WHICH BASELINE OBJECT TO USE, AND IS STRONGLY ADVISED AGAINST. INSTEAD THE USED IS ENCOURAGED TO RUN BUNBASELINE() AND SAVE THE OUTPUT AND USE THIS IN ALL FUNCITONS REQUIRING A BASELINE OBJECT:
	
	# Save the baseline object to the project environment, but only if at least all but one of the processes are present:
	#project_baseline <- paste0(getProjectName(projectName), "_baseline")
	#if(startProcess==1 && endProcess >= numProcesses - 1 && !project_baseline %in% ls(get(getProjectEnvName()))){
	#  assign(project_baseline, baseline, envir=get(getProjectEnvName()))
	#}
	# Output the baseline model:
	baseline
}
#'
#' @export
#' @rdname runBaseline
#' 
getBaseline <- function(projectName, input=c("par", "proc"), proc=NULL, fun=FALSE, drop=TRUE){
	# Locate the baseline object:
	if(is.character(projectName)){
		#projectName_baseline <- paste0(projectName, "_baseline")
	  #if(projectName_baseline %in% ls(get(getProjectEnvName()))){
	  #  baseline <- get(projectName_baseline, envir=get(getProjectEnvName()))
	  #}
		#else{
      baseline <- runBaseline(projectName)
		#}
  }
  else{
    baseline <- projectName
  }
	processes <- getBaselineParameters(baseline, discardSave=TRUE)
	processNames <- names(processes)
	functionNames <- sapply(processes, "[[", "functionName")
	
	######################################################
	##### (1) Get a list of processes with paramers: #####
	if("par" %in% input){
		input <- c(processNames, input)
	}
	# par = FALSE suppresses returning parameters of the baseline:
	if(!identical(input, FALSE)){
    parameters <- processes[intersect(input, processNames)]
	}
	else{
		parameters = NULL
	}
	######################################################
	
	###########################################
	##### (2) Get output from processes, possibly specified by function names using 'fun', in which case the name of the process does not matter, and if there are more than one process using the same funciton, the first is chosen: #####
	if(!identical(fun, FALSE)){
		# Discard process names if any funciton names are given!:
		proc <- FALSE
		# Find the functions:
		atMatchedFunctions <- na.omit(match(fun, functionNames))
		matchedProcesses <- processNames[atMatchedFunctions]
		matchedFunctions <- functionNames[atMatchedFunctions]
		# Read the output data:
		suppressWarnings(outputData <- lapply(matchedFunctions, function(xx) getDataFrame(baseline, functionName=xx)))
		names(outputData) <- matchedProcesses
 	}
	else if(!identical(proc, FALSE)){
		if(isTRUE(proc) || length(proc)==0){
			matchedProcesses <- processNames
		}
		else{
			matchedProcesses <- intersect(proc, processNames)
		}
		suppressWarnings(outputData <- lapply(matchedProcesses, function(xx) getDataFrame(baseline, processName=xx)))
		names(outputData) <- matchedProcesses
	}
	else{
		outputData <- NULL
	}
	
	###########################################
	
	###########################################
	##### (3) Get a list of process data: #####
  processdataNames <- baseline$getProject()$getProcessData()$getOutputOrder()$toArray()
  if("proc" %in% input){
		input <- c(processdataNames, input)
	}
	processdataNames <- intersect(processdataNames, input)
	processData <- lapply(processdataNames, function(xx) getProcessDataTableAsDataFrame(baseline, xx))
	names(processData) <- processdataNames
  ###########################################
	
	# Return the data:
	out <- list(parameters=parameters, outputData=outputData, processData=processData)
	if(drop){
		out <- out[sapply(out, length)>0]
		while(is.list(out) && length(out)==1){
		  out <- out[[1]]
		}
	}
	out
}
#'
#' @export
#' @rdname runBaseline
#' 


#*********************************************
#*********************************************
#' Run (or get without running, nostly used internal in Rstox) a baseline model created by StoX
#' 
#' Overrides baseline parameters by new values specified in 'parList' or '...'.
#' 
#' @param baseline The baseline object (strict: needs to be a baseline object only, not the name of a project).
#' @param save Logical; if TRUE changes to the project specified in "..." are saved to the project.xml file. Default is FALSE, and one should be aware that changes are non-reversable.
#' @param parList List of parameters values overriding existing parameter values. These are specified as processName = list(parameter = value), for example AcousticDensity = list(a = -70, m = 10), BioStationWeighting = list(WeightingMethod = "NASC", a = -70, m = 10). Numeric parameters must be given as numeric, string parameters as string, and logical parameters (given as strings "true"/"false" in StoX) can be given as logical TRUE/FALSE.
#' @param ... Same as parList, but can be specified separately (not in a list but as separate inputs).
#'
#' @return The original parameters
#'
#' @export
#' @rdname overrideBaselineParameters
#'
overrideBaselineParameters <- function(baseline, save=FALSE, parList=list(), ...){
  # Include both parameters specified in 'parList' and parameters specified freely in '...':
  dotlist <- list(...)
  if(length(dotlist)){
    dotlist <- dotlist[sapply(dotlist, is.list)]
    dotlist <- dotlist[sapply(dotlist, length)>0]
  }
  parList <- c(parList, dotlist)
	
  # Override parameters in the baseline:
  if(length(parList)>0){
    # Get process names:
    processName <- names(getBaselineParameters(baseline, discardSave=TRUE))
	  
    changeProcesses <- names(parList)
    numParameters <- unlist(lapply(parList, length))
    changeProcesses <- rep(changeProcesses, numParameters)
	  changeProcessesIdx <- match(changeProcesses, processName)-1
		changeParameters <- unlist(lapply(parList, names))
    # Values must be a list since it can hold different types (logical, string): 
    changeValues <- unlist(parList, recursive=FALSE)
	  
		# Issue a warning if there are non-existent processes, and remove these in the for loop below:
		nonExistent <- is.na(changeProcessesIdx)
		if(any(nonExistent)){
			warning("parList or ... contains non-existent processes, which were removed. Use names(getBaseline(input=\"par\", proc=FALSE)) to get a list of processes.")
			if(all(nonExistent)){
				return(list())
			}
			changeProcesses <- changeProcesses[!nonExistent]
			changeProcessesIdx <- changeProcessesIdx[!nonExistent]
			changeValues <- changeValues[!nonExistent]
		}
    
		# Set logical values to "true"/"false":
    logicalValues <- sapply(changeValues, is.logical)
    changeValues[logicalValues] <- lapply(changeValues[logicalValues], function(xx) if(xx) "true" else "false")
    changeValues <- as.character(unlist(changeValues, use.names=FALSE))
    
	  # Change the parameter values and return the original values:
	  originalValues <- changeValues
    for(i in seq_along(changeProcessesIdx)){
	    originalValues[i] <- baseline$getProcessList()$get(as.integer(changeProcessesIdx[i]))$getParameterValue(changeParameters[i])
	    baseline$getProcessList()$get(as.integer(changeProcessesIdx[i]))$setParameterValue(changeParameters[i], changeValues[i])
  	  print(data.frame(process=changeProcesses, oldValue=originalValues, newValue=changeValues))
    }
    if(save){
      saveProject(baseline)
    }
    # Return the original values:
    out <- vector("list", length(changeProcesses))
    names(out) <- changeProcesses
    for(i in seq_along(out)){
      thisout <- list(originalValues[i])
      names(thisout) <- changeParameters[i]
      out[[i]] <- thisout
    }
    out
  }
}


#*********************************************
#*********************************************
#' Get the parameter values of all processes in the baseline.
#' 
#' Reads the project.xml file and extracts a list of all parameters of each process, including the function name. Previously, the Rstox java access was used for this, but due to reflection used in rJava, this was a slow process.
#' 
#' @param projectName the name of an existing StoX project.
#'
#' @return A list of one element for each process in the baseline, each holding the parameters of the process in a list with the parameter names as names of the list.
#'
#' @examples
#' \dontrun{
#' system.time(p <- getBaselineParameters("Test_Rstox"))}
#'
#' @export
#' @rdname getBaselineParameters
#'
getBaselineParameters <- function(projectName, discardSave=TRUE){
	# Read project.xml:
	l <- readLines(file.path(getProjectDir(projectName), "process", "project.xml"))
	# Extract the lines with baseline processes:
	atBaseline <- grep("<model name=\"baseline\">", l, fixed=TRUE)
	atModelEnd <- grep("</model>", l, fixed=TRUE)
	atModelEnd <- min(atModelEnd[atModelEnd>atBaseline])
	l <- l[seq(atBaseline, atModelEnd)]
	# Get the process names:
	atName <- grep("<process name=", l, fixed=TRUE)
	processNames <- unlist(lapply(l[atName], function(xx) strsplit(xx, "\"", fixed=TRUE)[[1]][2]))
	# Get the function names:
	atFunction <- grep("<function>", l, fixed=TRUE)
	atFunction1 <- regexpr("<function>", l, fixed=TRUE)
	atFunction1 <- atFunction1[atFunction1>0] + attr(atFunction1,"match.length")[atFunction1>0]
	atFunction2 <- regexpr("</function>", l, fixed=TRUE)
	atFunction2 <- atFunction2[atFunction2>0] - 1
	processFunctions <- substr(l[atFunction], atFunction1, atFunction2)
  # Get the parameter names and values:
	atParameter <- grep("<parameter name=", l, fixed=TRUE)
	processOfParameter <- findInterval(atParameter, atName)
	parameterNames <- unlist(lapply(l[atParameter], function(xx) strsplit(xx, "\"", fixed=TRUE)[[1]][2]))
	parameterValues <- unlist(lapply(l[atParameter], function(xx) substr(xx, min(gregexpr(">", xx, fixed=TRUE)[[1]])+1, max(gregexpr("<", xx, fixed=TRUE)[[1]])-1)))
	names(parameterValues) <- parameterNames
  # Return the data:
	out <- lapply(seq_along(processNames), function(i) c(list(functionName=processFunctions[i]), parameterValues[processOfParameter==i]))
	names(out) <- processNames
	if(discardSave){
		out <- out[sapply(out, "[[", "functionName")!="WriteProcessData"]
	}
	out
}
#'
#' @export
#' @rdname getBaselineParameters
#'
getVar <- function(x, var){
	if(var %in% names(x)){
		x[[var]]
	}
	else{
		stop(paste0("Variable ", var, " not present in the data frame \"", deparse(substitute(x)), "\""))
	}
}


#*********************************************
#*********************************************
#' Get joined table of trawl assignments, psu and stratum
#'
#' Get trawl assignments from baseline in StoX Java memory.
#'
#' @param baseline StoX Java baseline object.
#'
#' @return Dataframe with  trawl assignments merged with psu and stratum
#'
#' @examples
#' \dontrun{
#' baseline <- getBaseline("Test_Rstox")  
#' assignments <- getBioticAssignments(baseline)}
#'
#' @export
#' @rdname getBioticAssignments
#' 
getBioticAssignments <- function(baseline) {
  ta <- getProcessDataTableAsDataFrame(baseline, 'bioticassignment')
  pa <- getProcessDataTableAsDataFrame(baseline, 'suassignment')
  ps <- getProcessDataTableAsDataFrame(baseline, 'psustratum')
  out <- merge(x=merge(x=ps, y=pa, by.x='PSU', by.y='SampleUnit'), y=ta, by='AssignmentID')
}

#*********************************************
#*********************************************
#' (Internal) Load environment from file or call a function in an environment
#'
#' Loads the file variables into a local environment returned.
#'
#' @param fileName the RData file with R objects OR the name of the project.
#' @param fileBaseName is the (base) name of the file (usually one of "rmodel.RData" and "impute.RData").
#' @param outputFolder is the output folder to use (usually one of "rmodel" and "report").
#'
#' @return The environment of the project, in which all data processed by Rstox are placed.
#'
#' @examples
#' \dontrun{
#' projectName <- "Test_Rstox"
#' # Create a StoX project in the StoX "Workspace" directory containing the example files in the Rstox:
#' proj <- createProject("Test_Rstox", acoustic=system.file("extdata", "Test_Rstox", package="Rstox"), ow=FALSE)
#' # Run the baseline model of the project:
#' proj <- runBaseline(projectName)
#' # Display the mean nautical area scattering (NASC) values per sampling unit:
#' psuNASC <- getBaseline(proj, data='MeanNASC', par=FALSE, proc=FALSE)
#' # Bootstrap the baseline model:
#' bootstrap_Acoustic <- runBootstrap(projectName, type="Acoustic", startProcess="TotalLengthDist", endProcess="SuperIndAbundance", numIterations=10, seed=1, cores=1, NASCDistr="observed")
#' # Save the bootstrap data:
#' saveRImage(projectName)
#' reportEnv <- loadEnv(projectName)
#' ls(reportEnv)}
#'
#' @export
#' @rdname loadEnv
#' 
loadEnv <- function(projectName, fileBaseName="rmodel.RData", outputFolder="rmodel", fileName=NULL){
	# Set the 'fileName', which is kept for compatibility with older versions, to the projectName if not given explicit:
	if(length(fileName)){
	  projectName <- fileName
	  }
	# Get the project environment, and load the file storing the environment if not already loaded:
	if(!is.environment(projectName)){
		# If the project environment is already loaded:
	  if(exists(getProjectEnvName(projectName)) && is.environment(getProjectEnv(projectName))){
	    reportEnv <- getProjectEnv(projectName)
	  }
		# Else load the file holding the environment:
	  else{
		  # If 'projectName' is not the path to a file, assume that the project name is specified:
		  if(!identical(file.info(projectName)$isdir, FALSE)){
		    fileName <- getRDataFileName(projectName, fileBaseName=fileBaseName, outputFolder=outputFolder)
		  }
			else{
				fileName <- projectName
			}
			# Open the project in order to create the project environment (added on 2016-09-19 after R Report failed):
		  openProject(projectName)
			# Load the data into the project environment:
			reportEnv <- getProjectEnv(projectName)
		  load(file=fileName, env=reportEnv)
	  }
		return(reportEnv)
	}
	else{
		return(projectName)
	}
}


#*********************************************
#*********************************************
#' Saves RStoX workspace or list to file
#'
#' Saves RStoX workspace variables to file in the project output directory. Any functions are excluded.
#'
#' @param projectName Name of the StoX project.
#' @param fileBaseName is the (base) name of the file.
#' @param outputFolder is the output folder to use (usually one of "rmodel" and "report").
#' @param ev environment object. Default is the environment of the project values except the functions (kept for compatibility with older versions).
#' @param fileName the RData file to with R objects will be saved (kept for compatibility with older versions).
#'
#' @return RData file name of the project
#'
#' @examples
#' \dontrun{
#' saveRImage("Test_Rstox")}
#'
#' @export
#' @rdname saveRImage
#' 
saveRImage <- function(projectName, fileBaseName="rmodel.RData", outputFolder="rmodel", ev=NULL, fileName=NULL){
  if(length(fileName)==0){
    fileName <- getRDataFileName(projectName, fileBaseName=fileBaseName, outputFolder=outputFolder)
  }
  # If 'projectName' is given and 'fileName' is non-empty and not the path to a file, assume that the basename of the file is specified in fileName:
  #else if(!missing(projectName) && !identical(file.info(fileName)$isdir, FALSE)){
  #  fileName <- getRDataFileName(projectName, fileBaseName=fileName, outputFolder=outputFolder)
  #}
  if(length(ev)==0){
    ev <- getProjectEnv(projectName)
  }
  save(list=ls(ev), file=fileName, envir=ev)
  fileName
}


#*********************************************
#*********************************************
#' (Internal) Functions to return various paths and file names.
#'
#' \code{getProjectDir} returns the project directory in locale charset. Note: The underlying rstox.jar is UTF-8 based.
#' \code{getProjectEnvName} returns the name of the project environment in which relevant outputs are assigned.
#' \code{getProjectEnv} gets the project environment.
#' \code{getRDataFileName} returns the path to a file to which to save the project environment.
#' \code{getProjectReportDir} returns the path to the project report directory.
#'
#' @param projectName The name of the project. In getProjectDir() projectName can also be a baseline object.
#' @param fileBaseName is the (base) name of the file.
#' @param outputFolder is the output folder to use (usually one of "rmodel" and "report").
#'
#' @return Various names and directories
#' 
#' @export
#' @rdname getProjectDir
#' 
getProjectDir <- function(projectName){
  if(is.character(projectName)){
    paste0(iconv(openProject(projectName)$getProjectFolder(), "UTF-8", localeToCharset()))
  }
  else{
    paste0(iconv(projectName$getProject()$getProjectFolder(), "UTF-8", localeToCharset()))
  }
}
#' 
#' @export
#' @rdname getProjectDir
#' 
getProjectEnvName <- function(projectName=NULL){
  paste(c("RstoxEnv",projectName), collapse="_")
}
#' 
#' @export
#' @rdname getProjectDir
#' 
getProjectEnv <- function(projectName){
  get(getProjectEnvName(projectName))
}
#' 
#' @export
#' @rdname getProjectDir
#' 
getRDataFileName <- function(projectName, fileBaseName="rmodel.RData", outputFolder="rmodel"){
  file.path(getProjectDir(projectName), "output", outputFolder, fileBaseName)
}
#' 
#' @export
#' @rdname getProjectDir
#' 
getProjectReportDir <- function(projectName){
  file.path(getProjectDir(projectName), "output", "report")
}
#' 
#' @export
#' @rdname getProjectDir
#' 
getProjectName <- function(projectName){
	# Allow for a baseline object as input:
	if(any(is(projectName)=="jobjRef")){
	  projectName <- projectName$getProject()$getProjectName()
	}
	else if(!is.character(projectName)){
		warning("Invalid projectName (must be a character sting or a baseline object)")
		return(NA)
	}
	projectName
}


#*********************************************
#*********************************************
#' Convert list to matrix and generate missing values
#'
#' Convert a list of vectors with variable length to a matrix with all possible variables in the columns, and with missing values
#'
#' @param x A list of vectors of one dimension with column names or names.
#'
#' @export
#' @rdname as.matrix_full
#' 
as.matrix_full <- function(x){
  # Scan for the field names:
  if(length(colnames(x[[1]]))==0){
    x <- lapply(x, t)
  }
  unames <- unique(unlist(lapply(x, colnames)))
  # Get elements that have all fields, and use the first one to define the order of the field names:
  fullLength <- sapply(x, length) == length(unames)
  if(any(fullLength)){
    unames <- colnames(x[[which(fullLength)[1]]])
    }
  # Fill inn the data:
  for(i in seq_along(x)){
    one <- rep(NA, length(unames))
    names(one) <- unames
    one[colnames(x[[i]])] <- x[[i]]
    x[[i]] <- one
    }
  out <- matrix(unlist(x, use.names=FALSE), ncol=length(unames), byrow=TRUE)
  rownames(out) <- NULL
  colnames(out) <- unames
  out
}
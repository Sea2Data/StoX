#*********************************************
#*********************************************
#' (Internal) Distribute unknown individual biological parameters from known values
#'
#' This function fills in holes in individual fish samples (also called imputation).
#' In cases where individuals are not aged, missing biological variables (e.g "weight","age","sex", and "specialstage") are sampled from 
#' fish in the same length group at the lowest imputation level possible.
#'    impLevel = 0: no imputation, biological information exists
#'    impLevel = 1: imputation at station level; biological information is selected at random from fish within station
#'    impLevel = 2: imputation at strata level; no information available at station level, random selection within stratum
#'    impLevel = 3: imputation at survey level; no information available at lower levels, random selection within suvey
#'    impLevel = 99: no imputation, no biological information exists for this length group
#'
#' @param abnd Abundance matrix with individual data
#' @param seedV The seed vector for the random number generator, where element 'i' is picked out (this may seem strange, but is a consequence of the parallelability of the function, where 'i' is the primary parameter).
#'
#' @return Abundance matrix with imputed biological information 
#'
#' @export
#' 
distributeAbundanceOld <- function(i=NULL, abnd, seedV=NULL) {
  if(length(i)==1 && !"Row" %in% names(abnd)){
    abnd = abnd[[i]]
  }
	
  msg <- double(6)
  abnd.distr.known <- abnd[abnd$age != "-" & abnd$includeintotal=="true",]
  #cat(paste0("Data have ", length(abnd.distr.known$age)," aged individuals.\n"))
  msg[1] <- length(abnd.distr.known$age)
  abnd.distr.unknown <- abnd[abnd$age == "-", ]
  #cat(paste0("Data have ", length(abnd.distr.unknown$age)," length sampled individuals without known age.\n"))
  msg[2] <- length(abnd.distr.unknown$age)
  
  if(length(abnd.distr.known$age) == 0){
    stop("No known ages")
  }
  abnd.distr.known$impLevel <- 0
  if(length(abnd.distr.unknown$age) == 0){
    warning("No unknown ages")
    return(abnd)
  }
  abnd.distr.unknown$impLevel <- 99
  ## Go through all rows in abundance matrix
  if(isTRUE(seedV[i])){
  	seedM <- matrix(c(1231234, 1234, 1234), ncol=nrow(abnd.distr.unknown), ncol=3, byrow=TRUE)
  }
  else{
    set.seed(seedV[i])
    # Create a seed matrix with 3 columns representing the replacement by station, stratum and survey:
    seedM <- matrix(sample(seq_len(10000000), 3*nrow(abnd.distr.unknown), replace = FALSE), ncol=3)
  }
  #set.seed(if(isTRUE(seed)) 1234 else if(is.numeric(seed)) seed else NULL) # seed==TRUE giving 1234 for compatibility with older versions
  #set.seed(seedV[i])
  #seedV <- sample(c(1:10000000), nrow(abnd.distr.unknown), replace = FALSE) # Makes seed vector for fixed seeds (for reproducibility).
  # Create a seed matrix with 3 columns representing the replacement by station, stratum and survey:
  #seedM <- matrix(sample(seq_len(10000000), 3*nrow(abnd.distr.unknown), replace = FALSE), ncol=3) # Makes seed matrix.
  for(i in 1: nrow(abnd.distr.unknown)){
	  id.known.sta <- id.known.stratum <- id.known.survey <- NULL

    ## Old comment, before changing station to serialno: Replace by station
    ## Replace by serialno
      id.known.sta <- abnd.distr.unknown$Stratum[i] == abnd.distr.known$Stratum &
      abnd.distr.unknown$cruise[i] == abnd.distr.known$cruise &
      #abnd.distr.unknown$serialno[i] == abnd.distr.known$serialno &
      # The variable station was changed to serialno (2016-08-31):
	    abnd.distr.unknown$serialno[i] == abnd.distr.known$serialno &
      abnd.distr.unknown$LenGrp[i] == abnd.distr.known$LenGrp
		if(any(id.known.sta)){
      known.data <- abnd.distr.known[id.known.sta,]
			set.seed(seedM[i,1]) # For reproducibility
      id.select.sta <- sample(1:length(known.data$age), size=1, replace=T)
      crep <- colnames(abnd.distr.unknown)[abnd.distr.unknown[i,] %in% c("-")]
      #if(any(is.na(crep))){
      #}
      abnd.distr.unknown[i,crep] <- known.data[id.select.sta,crep]
      abnd.distr.unknown$impLevel[i] <- 1
      next
    }
    ## Replace by stratum
    if(!any(id.known.sta)){
      id.known.stratum <- abnd.distr.unknown$Stratum[i] == abnd.distr.known$Stratum &
        abnd.distr.unknown$LenGrp[i] == abnd.distr.known$LenGrp
      if(any(id.known.stratum)){
        known.data.stratum <- abnd.distr.known[id.known.stratum,]
        set.seed(seedM[i,2]) # For reproducibility
        id.select.stratum <- sample(1:length(known.data.stratum$age), size=1, replace=T)
        crep <- colnames(abnd.distr.unknown)[abnd.distr.unknown[i,] %in% c("-")]
        abnd.distr.unknown[i,crep] <- known.data.stratum[id.select.stratum,crep]
        abnd.distr.unknown$impLevel[i] <- 2
        next
      }
    }
    ## Replace by survey
    if(!any(id.known.stratum)) {
      id.known.survey <- abnd.distr.unknown$LenGrp[i] == abnd.distr.known$LenGrp
      if(any(id.known.survey)){
        known.data.survey <- abnd.distr.known[id.known.survey,]
        set.seed(seedM[i,3]) # For reproducibility
        id.select.survey <- sample(1:length(known.data.survey$age), size=1, replace=T)
        crep <- colnames(abnd.distr.unknown)[abnd.distr.unknown[i,] %in% c("-")]
        abnd.distr.unknown[i,crep] <- known.data.survey[id.select.survey,crep]
        abnd.distr.unknown$impLevel[i] <- 3
        next
      }
    }
  }
  #cat(paste0(length(abnd.distr.unknown$impLevel[abnd.distr.unknown$impLevel==1])," individual ages were imputed at station level. \n"))
  #cat(paste0(length(abnd.distr.unknown$impLevel[abnd.distr.unknown$impLevel==2])," individual ages were imputed at strata level. \n"))
  #cat(paste0(length(abnd.distr.unknown$impLevel[abnd.distr.unknown$impLevel==3])," individual ages were imputed at survey level. \n"))
  #cat(paste0(length(abnd.distr.unknown$impLevel[abnd.distr.unknown$impLevel==99])," individual ages were not possible to impute. \n"))
  #msg[3] <- length(abnd.distr.unknown$impLevel[abnd.distr.unknown$impLevel==1])
  #msg[4] <- length(abnd.distr.unknown$impLevel[abnd.distr.unknown$impLevel==2])
  #msg[5] <- length(abnd.distr.unknown$impLevel[abnd.distr.unknown$impLevel==3])
  #msg[6] <- length(abnd.distr.unknown$impLevel[abnd.distr.unknown$impLevel==99])
  msg[3] <- sum(abnd.distr.unknown$impLevel==1)
  msg[4] <- sum(abnd.distr.unknown$impLevel==2)
  msg[5] <- sum(abnd.distr.unknown$impLevel==3)
  msg[6] <- sum(abnd.distr.unknown$impLevel==99)
  
  out <- rbind(abnd.distr.known,abnd.distr.unknown)
  out <- out[order(out$Row),]
  list(data=out, msg=msg)
}

#*********************************************
#*********************************************
#' (Internal) Distribute unknown individual biological parameters from known values
#'
#' This function fills in holes in individual fish samples (also called imputation).
#' In cases where individuals are not aged, missing biological variables (e.g "weight","age","sex", and "specialstage") are sampled from 
#' fish in the same length group at the lowest imputation level possible.
#'    impLevel = 0: no imputation, biological information exists
#'    impLevel = 1: imputation at station level; biological information is selected at random from fish within station
#'    impLevel = 2: imputation at strata level; no information available at station level, random selection within stratum
#'    impLevel = 3: imputation at survey level; no information available at lower levels, random selection within suvey
#'    impLevel = 99: no imputation, no biological information exists for this length group
#'
#' @param abnd Abundance matrix with individual data
#' @param seedV The seed vector for the random number generator, where element 'i' is picked out (this may seem strange, but is a consequence of the parallelability of the function, where 'i' is the primary parameter).
#'
#' @return Abundance matrix with imputed biological information 
#'
#' @export
#' 
distributeAbundanceOldTemp <- function(i=NULL, abnd, seedV=NULL) {
  if(length(i)==1 && !"Row" %in% names(abnd)){
    abnd = abnd[[i]]
  }
  
	atKnown = which(abnd$age != "-" & abnd$includeintotal=="true")
	atUnknown = which(abnd$age == "-")
	N <- nrow(abnd)
	imputeRows <- rep("-", N)
	
	msg <- double(6)
  abnd.distr.known <- abnd[abnd$age != "-" & abnd$includeintotal=="true",]
	#cat(paste0("Data have ", length(abnd.distr.known$age)," aged individuals.\n"))
  msg[1] <- length(abnd.distr.known$age)
  abnd.distr.unknown <- abnd[abnd$age == "-", ]
  #cat(paste0("Data have ", length(abnd.distr.unknown$age)," length sampled individuals without known age.\n"))
  msg[2] <- length(abnd.distr.unknown$age)
  
  if(length(abnd.distr.known$age) == 0){
    stop("No known ages")
  }
  abnd.distr.known$impLevel <- 0
  if(length(abnd.distr.unknown$age) == 0){
    warning("No unknown ages")
    return(abnd)
  }
  abnd.distr.unknown$impLevel <- 99
  ## Go through all rows in abundance matrix
  if(isTRUE(seedV[i])){
  	seedM <- matrix(c(1231234, 1234, 1234), ncol=nrow(abnd.distr.unknown), ncol=3, byrow=TRUE)
  }
  else{
    set.seed(seedV[i])
    # Create a seed matrix with 3 columns representing the replacement by station, stratum and survey:
    seedM <- matrix(sample(seq_len(10000000), 3*nrow(abnd.distr.unknown), replace = FALSE), ncol=3)
  }
	#set.seed(if(isTRUE(seed)) 1234 else if(is.numeric(seed)) seed else NULL) # seed==TRUE giving 1234 for compatibility with older versions
  #set.seed(seedV[i])
  #seedV <- sample(c(1:10000000), nrow(abnd.distr.unknown), replace = FALSE) # Makes seed vector for fixed seeds (for reproducibility).
  # Create a seed matrix with 3 columns representing the replacement by station, stratum and survey:
  #seedM <- matrix(sample(seq_len(10000000), 3*nrow(abnd.distr.unknown), replace = FALSE), ncol=3) # Makes seed matrix.
	for(i in 1: nrow(abnd.distr.unknown)){
	  id.known.sta <- id.known.stratum <- id.known.survey <- NULL

    ## Old comment, before changing station to serialno: Replace by station
    ## Replace by serialno
      id.known.sta <- abnd.distr.unknown$Stratum[i] == abnd.distr.known$Stratum &
      abnd.distr.unknown$cruise[i] == abnd.distr.known$cruise &
      #abnd.distr.unknown$serialno[i] == abnd.distr.known$serialno &
      # The variable station was changed to serialno (2016-08-31):
	    abnd.distr.unknown$serialno[i] == abnd.distr.known$serialno &
      abnd.distr.unknown$LenGrp[i] == abnd.distr.known$LenGrp
		if(any(id.known.sta)){
      known.data <- abnd.distr.known[id.known.sta,]
			set.seed(seedM[i,1]) # For reproducibility
      id.select.sta <- sample(1:length(known.data$age), size=1, replace=T)
			crep <- colnames(abnd.distr.unknown)[abnd.distr.unknown[i,] %in% c("-")]
			
			imputeRows[atUnknown[i]] = atKnown[id.known.sta][id.select.sta]
			
			abnd.distr.unknown[i,crep] <- known.data[id.select.sta,crep]
      abnd.distr.unknown$impLevel[i] <- 1
      next
    }
    ## Replace by stratum
    if(!any(id.known.sta)){
			id.known.stratum <- abnd.distr.unknown$Stratum[i] == abnd.distr.known$Stratum &
        abnd.distr.unknown$LenGrp[i] == abnd.distr.known$LenGrp
      if(any(id.known.stratum)){
        known.data.stratum <- abnd.distr.known[id.known.stratum,]
        set.seed(seedM[i,2]) # For reproducibility
        id.select.stratum <- sample(1:length(known.data.stratum$age), size=1, replace=T)
        crep <- colnames(abnd.distr.unknown)[abnd.distr.unknown[i,] %in% c("-")]
				
				imputeRows[atUnknown[i]] = atKnown[id.known.stratum][id.select.stratum]
				
        abnd.distr.unknown[i,crep] <- known.data.stratum[id.select.stratum,crep]
        abnd.distr.unknown$impLevel[i] <- 2
        next
      }
    }
    ## Replace by survey
    if(!any(id.known.stratum)) {
			id.known.survey <- abnd.distr.unknown$LenGrp[i] == abnd.distr.known$LenGrp
      if(any(id.known.survey)){
        known.data.survey <- abnd.distr.known[id.known.survey,]
        set.seed(seedM[i,3]) # For reproducibility
        id.select.survey <- sample(1:length(known.data.survey$age), size=1, replace=T)
        crep <- colnames(abnd.distr.unknown)[abnd.distr.unknown[i,] %in% c("-")]
				
				imputeRows[atUnknown[i]] = atKnown[id.known.survey][id.select.survey]
				
        abnd.distr.unknown[i,crep] <- known.data.survey[id.select.survey,crep]
        abnd.distr.unknown$impLevel[i] <- 3
        next
      }
    }
  }
  #cat(paste0(length(abnd.distr.unknown$impLevel[abnd.distr.unknown$impLevel==1])," individual ages were imputed at station level. \n"))
  #cat(paste0(length(abnd.distr.unknown$impLevel[abnd.distr.unknown$impLevel==2])," individual ages were imputed at strata level. \n"))
  #cat(paste0(length(abnd.distr.unknown$impLevel[abnd.distr.unknown$impLevel==3])," individual ages were imputed at survey level. \n"))
  #cat(paste0(length(abnd.distr.unknown$impLevel[abnd.distr.unknown$impLevel==99])," individual ages were not possible to impute. \n"))
  #msg[3] <- length(abnd.distr.unknown$impLevel[abnd.distr.unknown$impLevel==1])
  #msg[4] <- length(abnd.distr.unknown$impLevel[abnd.distr.unknown$impLevel==2])
  #msg[5] <- length(abnd.distr.unknown$impLevel[abnd.distr.unknown$impLevel==3])
  #msg[6] <- length(abnd.distr.unknown$impLevel[abnd.distr.unknown$impLevel==99])
  msg[3] <- sum(abnd.distr.unknown$impLevel==1)
  msg[4] <- sum(abnd.distr.unknown$impLevel==2)
  msg[5] <- sum(abnd.distr.unknown$impLevel==3)
  msg[6] <- sum(abnd.distr.unknown$impLevel==99)
	
	out <- rbind(abnd.distr.known,abnd.distr.unknown)
  out <- out[order(out$Row),]
  #list(data=out, msg=msg, atUnknown=atUnknown, imputeRows=imputeRows)
  list(data=out, msg=msg)
}

#*********************************************
#*********************************************
#' (Internal) Distribute unknown individual biological parameters from known values
#'
#' This function fills in holes in individual fish samples (also called imputation).
#' In cases where individuals are not aged, missing biological variables (e.g "weight","age","sex", and "specialstage") are sampled from 
#' fish in the same length group at the lowest imputation level possible.
#'    impLevel = 0: no imputation, biological information exists
#'    impLevel = 1: imputation at station level; biological information is selected at random from fish within station
#'    impLevel = 2: imputation at strata level; no information available at station level, random selection within stratum
#'    impLevel = 3: imputation at survey level; no information available at lower levels, random selection within suvey
#'    impLevel = 99: no imputation, no biological information exists for this length group
#'
#' @param abnd Abundance matrix with individual data
#' @param seedV The seed vector for the random number generator, where element 'i' is picked out (this may seem strange, but is a consequence of the parallelability of the function, where 'i' is the primary parameter).
#'
#' @return Abundance matrix with imputed biological information 
#'
#' @export
#' 
distributeAbundance <- function(i=NULL, abnd, seedV=NULL) {
  if(length(i)==1 && !"Row" %in% names(abnd)){
    abnd = abnd[[i]]
  }
	N <- nrow(abnd)
	
	
	# Get the indices of known (with includeintotal==TRUE) and unknown ages:
	atKnownAge <- which(getVar(abnd, "age") != "-" & getVar(abnd, "includeintotal")=="true")
	atUnknownAge <- which(getVar(abnd, "age") == "-")
	NatKnownAge <- length(atKnownAge)
	NatUnknownAge <- length(atUnknownAge)
	msg <- double(6)
	msg[1] <- NatKnownAge
	msg[2] <- NatUnknownAge
	
 # Stop if no known ages and return if no unknown:
	if(NatKnownAge == 0){
    stop("No known ages")
  }
  if(NatUnknownAge == 0){
    warning("No unknown ages")
	  abnd$impLevel <- 0
	  return(list(data=abnd, msg=msg, indMissing=NULL, indReplacement=NULL, seedM=NULL))
	}

  # Set the seed matrix:
  if(isTRUE(seedV[i])){
  	seedM <- matrix(c(1231234, 1234, 1234), ncol=NatUnknownAge, ncol=3, byrow=TRUE)
  }
  else{
    set.seed(seedV[i])
    # Create a seed matrix with 3 columns representing the replacement by station, stratum and survey:
    seedM <- matrix(sample(seq_len(10000000), 3*NatUnknownAge, replace = FALSE), ncol=3)
  }
	
	# Run through the unknown rows and get indices for rows at which the missing data should be extracetd:
	imputeRows <- rep("-", N)
  imputeLevels <- integer(N)
	for(atUnkn in seq_along(atUnknownAge)){
		indUnkn <- atUnknownAge[atUnkn]
		# Get indice for which of the rows with known ages that have the same station, stratum and survey as the current unknown individual:
		matchStratum <- getVar(abnd, "Stratum")[indUnkn] == getVar(abnd, "Stratum")[atKnownAge]
		matchcruise <- getVar(abnd, "cruise")[indUnkn] == getVar(abnd, "cruise")[atKnownAge]
		matchserialno <- getVar(abnd, "serialno")[indUnkn] == getVar(abnd, "serialno")[atKnownAge]
		matchLenGrp <- getVar(abnd, "LenGrp")[indUnkn] == getVar(abnd, "LenGrp")[atKnownAge]
		id.known.sta <- atKnownAge[ which(matchStratum & matchcruise & matchserialno & matchLenGrp) ]
		id.known.stratum <- atKnownAge[ which(matchStratum & matchLenGrp) ]
		id.known.survey <- atKnownAge[ which(matchLenGrp) ]
		Nid.known.stratum <- length(id.known.stratum)
		Nid.known.sta <- length(id.known.sta)
		Nid.known.survey <- length(id.known.survey)
												
    ## Replace by station:
   	if(any(id.known.sta)){
      set.seed(seedM[atUnkn,1])
			imputeRows[indUnkn] <- id.known.sta[.Internal(sample(Nid.known.sta, 1L, FALSE, NULL))]
      imputeLevels[indUnkn] <- 1L
    }
    ## Replace by stratum:
    else if(any(id.known.stratum)){
      set.seed(seedM[atUnkn,2])
      imputeRows[indUnkn] <- id.known.stratum[.Internal(sample(Nid.known.stratum, 1L, FALSE, NULL))]
      imputeLevels[indUnkn] <- 2L
    }
    ## Replace by survey:
    else if(any(id.known.survey)) {
      set.seed(seedM[atUnkn,3])
      imputeRows[indUnkn] <- id.known.survey[.Internal(sample(Nid.known.survey, 1L, FALSE, NULL))]
      imputeLevels[indUnkn] <- 3L
    }
		else{
			imputeLevels[indUnkn] <- 99L
		}
  }
	abnd$impLevel <- imputeLevels
	abnd$impRow <- imputeRows
  # Store process info:
	msg[3] <- sum(abnd$impLevel[atUnknownAge]==1)
  msg[4] <- sum(abnd$impLevel[atUnknownAge]==2)
  msg[5] <- sum(abnd$impLevel[atUnknownAge]==3)
  msg[6] <- sum(abnd$impLevel[atUnknownAge]==99)
  
  # Create the following two data frames: 1) the rows of abnd which contain missing age and where there is age available in other rows, and 2) the rows with age available for imputing:
	missing <- abnd[atUnknownAge, , drop=FALSE]
	available <- abnd[imputeRows[atUnknownAge], , drop=FALSE]
	# Get the indices of missing data in 'missing' which are present in 'available':
	ind <- which(missing == "-" & available != "-", arr.ind=TRUE)
	indMissing <- cbind(missing$Row[ind[,1]], ind[,2])
	indReplacement <- cbind(available$Row[ind[,1]], ind[,2])
	
	# Apply the replacement. This may be moved to the funciton imputeByAge() in the future to allow for using previously generated indices:
	if(length(indMissing)){
		abnd[indMissing] <- abnd[indReplacement]
	}
	
  #list(data=abnd, msg=msg, indMissing=indMissing, indReplacement=indReplacement, atUnknownAge=atUnknownAge, imputeRows=imputeRows, seedM=seedM)
  list(data=abnd, msg=msg, indMissing=indMissing, indReplacement=indReplacement, seedM=seedM)
}


#*********************************************
#*********************************************
#' Impute  missing individual data by age
#' 
#' Impute missing data within the bootstrap data object
#' 
#' @param projectName the name of the StoX project.
#' @param type the type of boostrapping. Currently implemented are "Acoustic" and "SweptArea". Abbreviations "a" and "s" are allowed.
#' @param seed The seed for the random number generator (used for reproducibility)
#' @param cores an integer giving the number of cores to run the bootstrapping over.
#' @param reportEnv Environment with R objects
#' @param bootstrapVariable The name of the bootstrap data object
#' 
#' @return Updated list with imputed bootstrap results 
#'
#' @examples
#' \dontrun{
#' bootstrap <- runBootstrap("Test_Rstox", type="a", startProcess="TotalLengthDist", endProcess="SuperIndAbundance", numIterations=10, seed=1, cores=1)
#' # imputeByAge() fills in empty cells and is extremely time consuming (use 'cores' to split the workload on many several cores):
#' system.time(bootstrap_Acoustic_imputed <- imputeByAge("Test_Rstox", type="Acoustic"))}
#'
#' @importFrom parallel detectCores makeCluster parLapplyLB stopCluster
#' @export
#' 
imputeByAge <- function(projectName, type=c("Acoustic", "SweptArea", "ECA"), seed=1, cores=1, reportEnv=NULL, old=FALSE){
  
  # Get the relevant bootstrap variable:
  if(tolower(substr(type[1], 1, 1)) == "a"){
    bootstrapVariableName <- "bootstrap_Acoustic"
  }
  else if(tolower(substr(type[1], 1, 1)) == "s"){
    bootstrapVariableName <- "bootstrap_SweptArea"
  }
  else if(tolower(substr(type[1], 1, 1)) == "e"){
    warning("Bootstrapping ECA is not yet avaiable")
    return()
  }
  else{
    warning(paste0("Bootstrap type ", type[1], " not recognized"))
    return()
  }
  
  # Read the saved data from the R model. In older versions the user loaded the file "rmodel.RData" separately, but in the current code the environment "RstoxEnv" is declared on load of Rstox, and all relevant outputs are assigned to this environment:
  reportEnv <- loadEnv(fileName=projectName)
    
  bootstrapVariable <- eval(parse(text=bootstrapVariableName), env=reportEnv)
  
  numIterations <- length(bootstrapVariable$AbByInd) ## The length of the data collection corresponds to the number of bootstrap iterations
  msg.out <- vector("list", numIterations)
  indMissing.out <- vector("list", numIterations)
  indReplacement.out <- vector("list", numIterations)
  seedM.out <- vector("list", numIterations)
  
  # Set the seed of the runs, either as a vector of 1234s, to comply with old code, where the seeed was allways 1234 (from before 2016), or as a vector of seeds sampled with the given seed, or as NULL, in which case the seed matrix 'seedM' of distributeAbundance() is set by sampling seq_len(10000000) without seed:
	if(isTRUE(seed)){
  	seedV = rep(TRUE, numIterations+1) # seed==TRUE giving 1234 for compatibility with older versions
  }
  else if(is.numeric(seed)){
    set.seed(seed)
  	seedV = sample(seq_len(10000000), numIterations+1, replace = FALSE)
  }
  else{
    seedV = NULL
  }
	
	# Store the bootstrap iteration names:
	namesOfIterations <- names(bootstrapVariable$AbByInd)
 
	# Impute biological information
	if(isTRUE(old)){
		bootstrapVariable$base.AbByInd <- distributeAbundanceOld(i=1, abnd=bootstrapVariable$base.AbByInd, seedV=tail(seedV,1))$data
	}
	else if(old==99){
  	bootstrapVariable$base.AbByInd <- distributeAbundanceOldTemp(i=1, abnd=bootstrapVariable$base.AbByInd, seedV=tail(seedV,1))$data
  }
  else{
  	bootstrapVariable$base.AbByInd <- distributeAbundance(i=1, abnd=bootstrapVariable$base.AbByInd, seedV=tail(seedV,1))$data
  }
   
  if(cores==1){
		for(i in 1:numIterations){ # Loop to all bootstrap results
			if(isTRUE(old)){
				thisiteration <- distributeAbundanceOld(i, abnd=bootstrapVariable$AbByInd, seedV=seedV)
			}
		  else if(old==99){
		  	thisiteration <- distributeAbundanceOldTemp(i, abnd=bootstrapVariable$AbByInd, seedV=seedV)
		  }
		  else{
		  	thisiteration <- distributeAbundance(i, abnd=bootstrapVariable$AbByInd, seedV=seedV)
		  }
			# Store the data from the current iteration:
			bootstrapVariable$AbByInd[[i]] <- thisiteration$data
      msg.out[[i]] <- thisiteration$msg
      indMissing.out[[i]] <- thisiteration$indMissing
      indReplacement.out[[i]] <- thisiteration$indReplacement
      seedM.out[[i]] <- thisiteration$seedM
      cat(paste0("This is iteration ", i, "/", numIterations, "\n"))
    }
  }
  else{
    # Do not run on more cores than physically available:
	  availableCores = detectCores()
	  if(cores>availableCores){
      warning(paste0("Only ", availableCores, " cores available (", cores, " requested)"))
      cores = availableCores
    }
	  #memoryOneCore <- J("java.lang.Runtime")$getRuntime()$totalMemory()*2^-20
    cat("Parallel imputing on", cores, "cores:\n")
    # Generate the clusters of time steps:
    cl<-makeCluster(cores)
		if(isTRUE(old)){
			out <- parLapplyLB(cl, seq_len(numIterations), distributeAbundanceOld, abnd=bootstrapVariable$AbByInd, seedV=seedV)
		}
		else if(old==99){
			out <- parLapplyLB(cl, seq_len(numIterations), distributeAbundanceOldTemp, abnd=bootstrapVariable$AbByInd, seedV=seedV)
	  }
	  else{
	  	out <- parLapplyLB(cl, seq_len(numIterations), distributeAbundance, abnd=bootstrapVariable$AbByInd, seedV=seedV)
	  }
    
    # End the parallel bootstrapping:
    stopCluster(cl)
		bootstrapVariable$AbByInd <- lapply(out, "[[", "data")
		# Add names ot the iterations:
		names(bootstrapVariable$AbByInd) <- namesOfIterations
    msg.out <- lapply(out, "[[", "msg")
		indMissing.out <- lapply(out, "[[", "indMissing")
		indReplacement.out <- lapply(out, "[[", "indReplacement")
		seedM.out <- lapply(out, "[[", "seedM")
	}
  msg.out <- t(as.data.frame(msg.out))
  colnames(msg.out) <- c("Aged", "NotAged", "ImputedAtStation", "ImputedAtStrata", "ImputedAtSurvey", "NotImputed")
  rownames(msg.out) <- paste0("Iter", seq_len(numIterations))
  
  # Store the output messages, the missing and replace indices, the seeds and other parameters of the imputing:
	bootstrapVariable$imputeParameters$msg.out <- msg.out
  bootstrapVariable$imputeParameters$indMissing.out <- indMissing.out
  bootstrapVariable$imputeParameters$indReplacement.out <- indReplacement.out
  bootstrapVariable$imputeParameters$seed.out <- seed
  bootstrapVariable$imputeParameters$seedV.out <- seedV
  bootstrapVariable$imputeParameters$seedM.out <- seedM.out
	bootstrapVariable$imputeParameters$type <- type
	bootstrapVariable$imputeParameters$cores <- cores
	
	# Assign the data to the environment of the project:
	assign(x=bootstrapVariableName, value=bootstrapVariable, envir=reportEnv)
  
	list(bootstrapVariable=bootstrapVariable, bootstrapMsg=msg.out)
}

#*********************************************
#*********************************************
#' Plot NASC distribution to file
#'
#' Plots both original and resampled NASC distributions;
#' histogram of NASC transect means together with distribution of resampled NASC values (line).
#' Probability densities, component density, are plotted (so that the histogram has a total area of one).
#' Plot is exported to a tif- or png-file
#'
#' @param projectName the name of the StoX project.
#' @param usetiff logical; if ‘TRUE’, the plot is saved as tiff, if false, as png.
#' 
#' @return Plot saved to file 
#'
#' @examples
#' \dontrun{
#' # Create  psuNASC and getResampledNASCDistr first, needed for plotting: 
#' bootstrap <- runBootstrap("Test_Rstox", type="a", startProcess="TotalLengthDist", endProcess="SuperIndAbundance", numIterations=10, seed=1, cores=1)
#' plotNASCDistribution("Test_Rstox")}
#'
#' @export
#' 
plotNASCDistribution<-function(projectName, usetiff=FALSE, reportEnv=NULL){
  # Read the saved data from the R model. In older versions the user loaded the file "rmodel.RData" separately, but in the current code the environment "RstoxEnv" is declared on load of Rstox, and all relevant outputs are assigned to this environment:
  reportEnv <- loadEnv(fileName=projectName)
	
  # If any of the psuNASC and resampledNASCDistr are missing in the report environment, issue an error:
  ls_reportEnv <- ls(reportEnv)
  if(!all(c("psuNASC", "resampledNASC") %in% ls_reportEnv)){
    stop(paste0("The objects psuNASC and getResampledNASCDistr missing. These are generated by runBootstrap()"))
  }
  
	psuNASC <- eval(parse(text="psuNASC"), env=reportEnv)
  resampledNASC <- eval(parse(text="resampledNASC"), env=reportEnv)
  if(getVar(psuNASC, "LayerType")[1]!="WaterColumn"){
    psuNASC <- aggPSUNASC(psuNASC)
  }
  
  # Define the file name and initiate the plot file:
  fn <- file.path(getProjectReportDir(projectName), paste0("NASC_Distribution", ifelse(usetiff, ".tif", ".png")))
  if(usetiff){
    tiff(fn, res=600, compression = "lzw", height=5, width=5, units="in")
  }
  else{
    png(fn, width=800, height=600)
  }
  # Run the plot
  tryCatch({
    hist(getVar(psuNASC, "Value"), breaks=20, freq=F, xlab="NASC transect means", ylab="Relative frequency", main=projectName) 
    lines(density(resampledNASC))
  }, finally = {
    # safe closure of image resource inside finally block
    dev.off()
  })
  fn
}


#*********************************************
#*********************************************
#' Plot abundance results to file (generic)
#' 
#' Plots boxplot of bootstrap results together with Coefficient of Variation (CV).
#' Prints summary table and plot is exported to a tif- or png-file.
#' 
#' 
#' @param reportEnv Environment with R objects
#' @param type the type of boostrapping. Currently implemented are "Acoustic" and "SweptArea". Abbreviations "a" and "s" are allowed.
#' @param grp1 Variable used to group results, e.g. "age", "LenGrp", "sex"
#' @param grp2 An optional second grouping variable
#' @param numberscale Scale results with e.g. 1000 or 1000000
#' @param maintitle Main title for plot (text)
#' 
#' @return Plot saved to file and abundance table printed
#'
#' @examples
#' \dontrun{
#' plotAbundance(projectName, type="Acoustic", grp1="age", numberscale=1000000)}
#'
#' @export
#' @import data.table
#' @importFrom gdata reorder.factor
#' 
plotAbundance <- function(projectName, type=c("Acoustic", "SweptArea", "ECA"), grp1="age", grp2=NULL, xlabtxt=NULL, maintitle="", numberscale = 1000000, usex11=FALSE, reportEnv=NULL){
  
  # Get the relevant bootstrap variable:
  if(tolower(substr(type[1], 1, 1)) == "a"){
    bootstrapVariableName <- "bootstrap_Acoustic"
  }
  else if(tolower(substr(type[1], 1, 1)) == "s"){
    bootstrapVariableName <- "bootstrap_SweptArea"
  }
  else if(tolower(substr(type[1], 1, 1)) == "e"){
    warning("Bootstrapping ECA is not yet avaiable")
    return()
  }
  else{
    warning(paste0("Bootstrap type ", type[1], " not recognized"))
    return()
  }

  # Read the saved data from the R model. In older versions the user loaded the file "rmodel.RData" separately, but in the current code the environment "RstoxEnv" is declared on load of Rstox, and all relevant outputs are assigned to this environment:
  reportEnv <- loadEnv(fileName=projectName)
   
  bootstrapVariable <- eval(parse(text=bootstrapVariableName), env=reportEnv)
  base <- bootstrapVariable$base.AbByInd
  base$age <- as.factor(base$age)
  strata <- unique(base$Stratum[base$includeintotal=="true"])
  base <- base[base$Stratum %in% strata, ] 
  
  DT <- rbindlist(bootstrapVariable$AbByInd,idcol=TRUE)

  ## Is any data in the grp1 input unkown?
  grp1.unknown <- TRUE
  if(!any((DT[[grp1]]) == "-")){
    DT[[grp1]] <- as.numeric(DT[[grp1]]) 
    grp1.unknown <- FALSE 
  }
  if(!is.null(grp2)){
    setkeyv(DT, cols=c(".id","Stratum", grp1, grp2))
  }
  else{
    setkeyv(DT, cols=c(".id","Stratum", grp1))
  }
  byGrp <- c(grp1, grp2,".id")
  tmp <- DT[Stratum %in% strata,.(Ab.Sum=sum(Abundance)/numberscale),by=byGrp]
  tmp1 <- as.data.frame(tmp)
  n.grp1 <- unique(tmp1[,grp1])
  n.grp2 <- unique(tmp1[,grp2])
  
  setkeyv(tmp, cols=c(".id", grp1))
  tmp <- tmp[CJ(unique(tmp$.id),n.grp1), allow.cartesian=TRUE]
  
  if(!is.null(grp2)){
    setkeyv(tmp, cols=c(".id", grp1,grp2))
    tmp <- tmp[CJ(unique(tmp$.id),n.grp1,n.grp2), allow.cartesian=TRUE]
  } 
  
  tmp$Ab.Sum[is.na(tmp$Ab.Sum)] <- 0 
    
  out4 <- tmp[, .("Ab.Sum.5%" = quantile(Ab.Sum, probs = .05,na.rm=T),
                  "Ab.Sum.50%" = quantile(Ab.Sum, probs = .50,na.rm=T),
                  "Ab.Sum.95%" = quantile(Ab.Sum, probs = .95,na.rm=T),
                  Ab.Sum.mean = mean(Ab.Sum,na.rm=T),
                  Ab.Sum.sd = sd(Ab.Sum,na.rm=T),
                  Ab.Sum.cv = sd(Ab.Sum,na.rm=T)/mean(Ab.Sum,na.rm=T)) 
              , by = c(grp1,grp2)]
  
  out4p <- as.data.frame(replace(out4,out4=="-",NA))
  print(out4p[order(as.numeric(out4p[,grp1])),])
  
  if(numberscale==1000000){
    ylabtxt <-  "Abundance (millions)"
  }
  if(numberscale==100000){
    ylabtxt <-  "Abundance (10^5)"
  }
  if(numberscale==10000){
    ylabtxt <-   "Abundance (10^4)"
  }
  if(numberscale==1000){
    ylabtxt <-  "Abundance (thousands)"
  }
  if(numberscale==1){
    ylabtxt <-  "Abundance"
  }
  
  if(is.null(xlabtxt) & !is.null(grp2)){
    xlabtxt <- paste(grp1,"by", grp2)
  }
  
  #fn <- paste(".", "/output/report/Bootstrap_Abundance_", grp1, grp2, ifelse(usex11, ".tif", ".png"), sep="")
  fn <- file.path(getProjectReportDir(projectName), paste0("Bootstrap_Abundance_", grp1, grp2, ifelse(usex11, ".tif", ".png")))
  if(file.exists(fn)){
    file.remove(fn)
  }
  if(is.null(xlabtxt)){
    xlabtxt <- paste(grp1)
  }
  tryCatch({
    if(usex11){
      x11()
  }
  else{
      png(fn, width=800, height=600)
  }
    par(mfrow=c(1,1), oma=c(2,2,2,2),mar=c(4,4,2,4))
    if(is.null(grp2)){      
      form <- paste0("Ab.Sum~", grp1)
      if(grp1.unknown == FALSE){ ## Fill in gaps in n.grp1
        n.grp1b <- seq(min(n.grp1),max(n.grp1), min(diff(sort(n.grp1))))
        plot(0, type="n",xlim=c(min(n.grp1b),max(n.grp1b)), ylim=c(0,max(tmp1$Ab.Sum)), xlab=xlabtxt, ylab=ylabtxt, axes=F)
        axis(1, at=axTicks(1,par()$xaxp))
        axis(2)
        b1 <-boxplot(as.formula(form), axes=F , plot=F,data=tmp1)
        at.names <- as.numeric(b1$names)
        bxp(b1, at=at.names,xlim=c(min(axTicks(1,par()$xaxp)),max(axTicks(1,par()$xaxp))), axes=F, 
            add=T, outline = FALSE, show.names=F)
        ## Sett inn cv-linjer
        par(new=TRUE)
        out4db <- as.data.frame(out4)
        out4db <- out4db[match(as.character(c("-",sort(unique(as.numeric(tmp1[,grp1][tmp1[,grp1] != "-"]))))),out4db[,grp1],),] 
        out4db <- out4db[!is.na(out4db[,grp1]),]
        plot(at.names,out4db$Ab.Sum.cv, xlim =c(min(n.grp1b),max(n.grp1b)),type='b',col=1,ylim=c(0,max(out4db$Ab.Sum.cv+0.1,na.rm=T)),lwd=1, ann=FALSE, axes=FALSE) 
        mtext("CV", side=4, line=3, cex=1)
        axis(4)
      }
          
      if(grp1.unknown == TRUE){
        plot(0, type="n",xlim=c(1,length(n.grp1)), ylim=c(0,max(tmp1$Ab.Sum)), xlab=xlabtxt, ylab=ylabtxt,axes=F)
        tmp1[,grp1] <- reorder.factor(tmp1[,grp1], new.order=as.character(c("-",sort(unique(as.numeric(tmp1[,grp1][tmp1[,grp1] != "-"]))))))
        axis(1, at=1:length(n.grp1),labels = levels(tmp1[,grp1]))
        axis(2)
        b1 <-boxplot(as.formula(form), axes=F , plot=F,data=tmp1)
        at.names <- 1:length(n.grp1)
        bxp(b1, at=at.names,xlim=c(1,length(n.grp1)), axes=F, 
            add=T, outline = FALSE, show.names=F)
        par(new=TRUE)
        out4db <- as.data.frame(out4)
        
        out4db[,grp1] <- reorder.factor(out4db[,grp1], new.order=as.character(c("-",sort(unique(as.numeric(out4db[,grp1][out4db[,grp1] != "-"]))))))
        out4db <- out4db[order(out4db[,grp1]),]
        
        plot(at.names,out4db$Ab.Sum.cv,type='b',col=1,ylim=c(0,max(out4db$Ab.Sum.cv+0.1,na.rm=T)),
             lwd=1, ann=FALSE, axes=FALSE) 
        mtext("CV", side=4, line=3, cex=1)
        axis(4)
      }
    }    
    
    ## If there is an input on grp2
    if(!is.null(grp2)){
      form <- paste0("Ab.Sum~",grp1)
      n.grp2 <- unique(tmp1[,grp2])
      ## Add some ticks values to get a non-overlap
      if(length(n.grp2) %% 2 == 0){
        at.corr <- (-(length(n.grp2)-1):(length(n.grp2)-1))[c(-length(n.grp2))] * (0.2/length(n.grp2))
      }
      #if(length(n.grp2) %% 2 != 0){
      else{
        at.corr <- (-(length(n.grp2)-1):(length(n.grp2)-1)) * (0.2/length(n.grp2))
      }
      
      #### If n.grp1 is an integer
      if(grp1.unknown == FALSE){ ## Fill in gaps in n.grp1
        n.grp1b <- seq(min(n.grp1),max(n.grp1), min(diff(sort(n.grp1))))
        for(i in 1:length(n.grp2)){
          if(i == 1){
            plot(0, type="n",xlim=c(min(n.grp1b),max(n.grp1b)), ylim=c(0,max(tmp1$Ab.Sum)), xlab=xlabtxt, ylab=ylabtxt, axes=F)
            axis(1, at=axTicks(1,par()$xaxp))
            axis(2)
          }
          b1 <-boxplot(as.formula(form), axes=F , plot=F,data=tmp1[tmp1[,grp2] == n.grp2[i],])
          at.names <- as.numeric(b1$names)
          bxp(b1, at=at.names+at.corr[i],xlim=c(min(axTicks(1,par()$xaxp)),max(axTicks(1,par()$xaxp))), axes=F, 
              add=T, boxwex = 0.4/length(n.grp2),outline = FALSE, boxcol=i, show.names=F)
        }
        ## Make the cv -lines in plot
        out4df <- as.data.frame(out4)
        par(new = TRUE)
        for(i in 1:length(n.grp2)){
          dat.in <- out4df[out4df[,grp2] == n.grp2[i],]
          at.names <- (dat.in[,grp1])
          par(new=TRUE)
          plot(at.corr[i] + at.names, dat.in$Ab.Sum.cv,xlim=c(min(n.grp1b),max(n.grp1b)), col=i,lwd=1, 
               xlab="",ylab="",type="b", axes=F,ylim=c(0,max(out4df$Ab.Sum.cv,na.rm=T)))
        }
      }
      
      ## 
      if(grp1.unknown == TRUE){
        for(i in 1:length(n.grp2)){
          if(i == 1){
            plot(0, type="n",xlim=c(1,length(n.grp1)), ylim=c(0,max(tmp1$Ab.Sum)), xlab=xlabtxt, ylab=ylabtxt,axes=F)
            tmp1[,grp1] <- reorder.factor(tmp1[,grp1], new.order=as.character(c("-",sort(unique(as.numeric(tmp1[,grp1][tmp1[,grp1] != "-"]))))))
            axis(1, at=1:length(n.grp1),labels = levels(tmp1[,grp1]))
            axis(2)
          }
          b1 <-boxplot(as.formula(form), axes=F , plot=F,data=tmp1[tmp1[,grp2] == n.grp2[i],])
          at.names <- 1:length(n.grp1)
          bxp(b1, at=at.names+at.corr[i],xlim=c(1,length(n.grp1)), axes=F, 
              add=T, boxwex = 0.4/length(n.grp2),outline = FALSE, boxcol=i, show.names=F)
        }
        
        ## Make the cv -lines in plot
        out4df <- as.data.frame(out4)       
        for(i in 1:length(n.grp2)){
          dat.in <- out4df[out4df[,grp2] == n.grp2[i],]
          dat.in[,grp1] <- reorder.factor(dat.in[,grp1], new.order=as.character(c("-",sort(unique(as.numeric(dat.in[,grp1][dat.in[,grp1] != "-"]))))))
          dat.in <- dat.in[order(dat.in[,grp1]),]
          at.names <- sort(match(as.character(dat.in[,grp1]),levels(tmp1[,grp1])))
          par(new = TRUE)
          plot(at.corr[i] + at.names,dat.in$Ab.Sum.cv,type='b',col=i,xlim=c(1,length(n.grp1)),ylim=c(0,max(out4df$Ab.Sum.cv+0.1,na.rm=T)),
               lwd=1, ann=FALSE, axes=FALSE)                    
        }
      }
      mtext("CV", side=4, line=3, cex=1)
      axis(4)  
      title(maintitle)
      par(fig = c(0, 1, 0, 1), oma = c(0, 0, 0, 0), mar = c(0, 0, 0, 0), new = TRUE)
      plot(0, 0, type = "n", bty = "n", xaxt = "n", yaxt = "n")
      legend(x="bottom",lty=1,legend=n.grp2, col=1:i, xpd=T, inset=c(3.1,0), horiz=T, bty="n")
    }
    
    if(usex11){
      dev.copy(tiff,filename=fn, res=600, compression = "lzw", height=10, width=15, units="in")
    }
  }, finally = {
    # safe closure of image resource inside finally block
    dev.off()
  })
  #system(paste0("open '" ,fn, "'"))
  fn
}


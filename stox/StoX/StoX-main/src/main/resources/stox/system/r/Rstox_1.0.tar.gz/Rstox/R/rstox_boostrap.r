#*********************************************
#*********************************************
#' (Internal) Bootstrap biotic stations
#'
#' Resample (bootstrap) trawl stations based on survey (Cruise) number and station numbers (SerialNo) to estimate uncertainty in estimates.
#'
#' @param baseline StoX Java baseline object
#' @param assignments Trawl assignment from baseline
#' @param psuNASC meanNASC from baseline
#' @param stratumNASC Strata NASC estimates from getNASCDistr(baseline)
#' @param resampledNASC Resampled NASC distribution
#' @param startProcess Defines start for the bootstrap routine; TotalLengthDist is default
#' @param endProcess Defines stop for the bootstrap routine; AbundanceByPopulationCategory is default
#' @param parameters Parameters set by user in Stox; 
#' \describe{
#'  \item{parameters$numIterations}{Number of bootstrap replicates}
#'  \item{parameters$seed}{The seed for the random number generator (used for reproducibility)}
#' }
#'
#' @return list with n = numIterations data.frames containing results from baseline and bootstrap replicates
#'
#' @export
#' @rdname bootstrapBioticAcoustic
#'
bootstrapBioticAcoustic<-function(baseline, assignments, psuNASC, stratumNASC, resampledNASC, startProcess="TotalLengthDist", endProcess="AbundanceByPopulationCategory", parameters){
  bootstrapParallel(assignments=assignments, psuNASC=psuNASC, stratumNASC=stratumNASC, resampledNASC=resampledNASC, startProcess=startProcess, endProcess=endProcess, numIterations=parameters$numIterations, seed=parameters$seed, cores=1, baseline=baseline)
}


#*********************************************
#*********************************************
#' (Internal) Bootstrap biotic stations Swept Area version
#'
#' Resample (bootstrap) trawl stations based on survey (Cruise) number and station numbers (SerialNo) to estimate uncertainty in estimates
#'
#' @param baseline StoX Java baseline object.
#' @param assignments Trawl assignment from baseline.
#' @param startProcess Defines start for the bootstrap routine; TotalLengthDist is default.
#' @param endProcess: Define stop for the bootstrap routine; AbundanceByInduviduals is default.
#' @param parameters: R-object with parameters read from rprocess.txt.
#' \describe{
#'  \item{parameters$numIterations}{Number of bootstrap replicates}
#'  \item{parameters$seed}{The seed for the random number generator (used for reproducibility)}
#' }
#'
#' @return list with n = numIterations data.frames containing results from baseline and bootstrap replicates
#'
#' @export
#' @rdname bootstrapBioticSweptArea
#'
bootstrapBioticSweptArea<-function(baseline, assignments, startProcess="TotalLengthDist", endProcess="SuperIndAbundance", parameters){
  bootstrapParallel(assignments=assignments, startProcess=startProcess, endProcess=endProcess, numIterations=parameters$numIterations, seed=parameters$seed, cores=1, baseline=baseline)
}  


#*********************************************
#*********************************************
#' (Internal) Run one bootstrap iteration of biotic stations and acoustic data 
#'
#' This function is used in bootstrapParallel().
#'
#' @param i the boostrap iteration number.
#' @param assignments Trawl assignment from baseline.
#' @param psuNASC meanNASC from baseline.
#' @param stratumNASC Strata NASC estimates from getNASCDistr(baseline).
#' @param resampledNASC Resampled NASC distribution.
#' @param startProcess Defines start process in the baseline model for the bootstrap routine; TotalLengthDist is default.
#' @param endProcess Defines stop process in the baseline model for the bootstrap routine; AbundanceByPopulationCategory is default.
#' @param seedV a vector of seeds. seedV[i] is used.
#' @param inputBaseline the baseline run on which to bootstrap.
#'
#' @return list with (1) the abundance by length in the bootstrap run, (2) the abundance by super individuals in the bootstrap run
#'
#' @export
#' @rdname bootstrapOneIteration
#'
bootstrapOneIteration <- function(i, assignments, strata, psuNASC=NULL, stratumNASC=NULL, resampledNASC=NULL, startProcess="TotalLengthDist", endProcess="SuperIndAbundance", seedV=NULL, inputBaseline=NULL){
	
  if(length(inputBaseline)>0){
    baseline = inputBaseline
  }
  # Define StoX matrix to modify:
  ta_table <- baseline$getProject()$getProcessData()$getMatrix("bioticassignment")
  if(length(psuNASC)>0){
    meanNASCmatrix <- baseline$findProcessByFunction("MeanNASC")$getOutput()$getData()
  }
  # Perform sampling drawing and replacement by stratum
  BootWeights <- data.frame()
  # Not effective if psuNASC has length 0:
  meanNASC <- psuNASC
  # Loop per strata:
  for(j in 1:length(strata)){
    stations <- unique(getVar(assignments, "StID")[getVar(assignments, "Stratum")==strata[j]])
    if(length(stations) == 0) next
    set.seed(seedV[i])
    # Resample BioStation:
    StID <- sample(stations, length(stations), replace = TRUE)
    # Count weights from resample:
    count <- as.data.frame(table(StID))
    count$Stratum <- strata[j]
    BootWeights<-rbind(BootWeights,count)
    # Find NASC scaling factor
    if(length(psuNASC)>0){
      sm <- stratumNASC$NASC.by.strata$strata.mean[stratumNASC$NASC.by.strata$Stratum==strata[j]]
      # Scaling factor:
      meanNASC$NASC.scale.f[meanNASC$Stratum==strata[j]] <- ifelse(sm>0,resampledNASC[i,j]/sm,0)
    }
  }
  # Update biostation weighting
  asg2 <- merge(assignments,BootWeights,by=c("Stratum", "StID"), all.x=TRUE)
  asg2$StationWeight <- ifelse(!is.na(asg2$Freq),asg2$StationWeight*asg2$Freq,0)
  # Update trawl assignment table in Stox Java object:
  setAssignments(ta_table=ta_table, assignments=asg2)

  # Scale and update NASC values
  if(length(psuNASC)>0){
    meanNASC$Value <- meanNASC$Value*meanNASC$NASC.scale.f
    # Update meanNASC object in Java memory:
    setMeanNASCValues(meanNASCmatrix, meanNASC)
  }
  # Run the sub baseline within Java
	baseline <- runBaseline(projectName=baseline, startProcess=startProcess, endProcess=endProcess, save=FALSE)
  # Store the result
  #list(res.AbByLength <- getDataFrame1(baseline, 'AbundanceByLength'), res.AbByInd <- getDataFrame1(baseline, 'SuperIndAbundance'))
	out <- getBaseline(baseline, fun=c('AbundanceByLength','SuperIndAbundance'), input=FALSE)
	names(out) <- c("AbByLength", "AbByInd")
	out
}


#*********************************************
#*********************************************
#' (Internal) Bootstrap biotic stations and acoustic data
#'
#' Resample (bootstrap) trawl stations based on survey (Cruise) number and station numbers (SerialNo) to estimate uncertainty in estimates.
#'
#' @param projectName the name of the StoX project.
#' @param assignments Trawl assignment from baseline.
#' @param psuNASC meanNASC from baseline.
#' @param stratumNASC Strata NASC estimates from getNASCDistr(baseline).
#' @param resampledNASC Resampled NASC distribution.
#' @param startProcess Defines start process in the baseline model for the bootstrap routine; TotalLengthDist is default.
#' @param endProcess Defines stop process in the baseline model for the bootstrap routine; AbundanceByPopulationCategory is default.
#' @param numIterations Number of bootstrap replicates.
#' @param seed The seed for the random number generator (used for reproducibility).
#' @param cores an integer giving the number of cores to run the bootstrapping over.
#' @param baseline (optional) a StoX baseline object returned from runBaseline().
#' @param parameters Parameters set by user in Stox (only kept for compatibility with older versions);.
#' \describe{
#'  \item{parameters$numIterations}{Number of bootstrap replicates}
#'  \item{parameters$seed}{The seed for the random number generator (used for reproducibility)}
#' }
#'
#' @return list with (1) the abundance by length in the orginal model, (2) the abundance by length in the bootstrap run, (3) the abundance by super individuals in the orginal model, (4) the abundance by super individuals in the bootstrap run
#'
#' @examples
#' \dontrun{
#' baseline <- runBaseline("Test_Rstox")
#' assignments <- getBioticAssignments(baseline=baseline)
#' psuNASC <- getPSUNASC(baseline=baseline)
#' stratumNASC <- getNASCDistr(baseline=baseline, psuNASC=psuNASC, NASCDistr="normal")
#' resampledNASC <- getResampledNASCDistr(baseline=baseline, psuNASC=psuNASC, stratumNASC=stratumNASC, parameters=list(seed=1, numIterations=50))
#' bootstrap_Acoustic <- bootstrapParallel(baseline=baseline, assignments=assignments, psuNASC=psuNASC, stratumNASC=stratumNASC, resampledNASC=resampledNASC, startProcess="TotalLengthDist", endProcess="SuperIndAbundance", parameters=list(numIterations=10, seed=1))}
#'
#' @importFrom parallel detectCores makeCluster parLapplyLB stopCluster
#' @export
#' @rdname bootstrapParallel
#'
bootstrapParallel <- function(projectName, assignments, psuNASC=NULL, stratumNASC=NULL, resampledNASC=NULL, startProcess="TotalLengthDist", endProcess="SuperIndAbundance", numIterations=5, seed=1, cores=1, baseline=NULL, parameters=list()){
	# Stop the funciton if both projectName and baseline are missing:
  if(length(baseline)==0 && missing(projectName)){
    stop("Either projectName or baseline must be given.")
  }
 
  # Allow for inputs given in 'numIterations' and 'seed' to prepare for the higher level functions bootstrapAcoustic() and runBootstrap():
  if(length(numIterations)>0){
    parameters$numIterations = numIterations
  }
  if(length(seed)>0){
    parameters$seed = seed
  }

  # Filter assignments against NASC:
  if(length(psuNASC)>0){
    assignments <- droplevels(subset(assignments, getVar(assignments, "Stratum") %in% getVar(psuNASC, "Stratum")))
  }
  # Unique trawl station ID:
  assignments$StID <- getVar(assignments, "Station")
  
  set.seed(if(isTRUE(parameters$seed)) 1234 else if(is.numeric(parameters$seed)) parameters$seed else NULL) # seed==TRUE giving 1234 for compatibility with older versions
  # Makes seed vector for fixed seeds (for reproducibility):
  seedV <- sample(c(1:10000000), parameters$numIterations, replace = FALSE)
  # Define strata, either by acoustic values (if psuNASC is given) or by the trawl assignments:
  strata <- unique(if(length(psuNASC)>0) getVar(psuNASC, "Stratum") else getVar(assignments, "Stratum"))
  
  # Store the abundance by length and individual in the original model:
  #base.AbByLength <- getDataFrame1(baseline, 'AbundanceByLength')
  #base.AbByInd <- getDataFrame1(baseline, 'SuperIndAbundance')
  base.AbByLength <- getBaseline(baseline, fun="AbundanceByLength", input=FALSE)
  base.AbByInd <- getBaseline(baseline, fun="SuperIndAbundance", input=FALSE)
	
	# If only one core is specified use apply:
  if(cores==1){
    # Run the baseline to get tables and to ensure that processes that the bootstrap baseline run depends on are present:
    if(length(baseline)==0){
      baseline <- runBaseline(projectName=projectName, save=FALSE)
    }
    out <- lapply(seq_len(parameters$numIterations), bootstrapOneIteration, assignments=assignments, strata=strata, psuNASC=psuNASC, stratumNASC=stratumNASC, resampledNASC=resampledNASC, startProcess=startProcess, endProcess=endProcess, seedV=seedV, inputBaseline=baseline)
  }
  else{
      # Do not run on more cores than physically available:
  	availableCores = detectCores()
  	if(cores>availableCores){
        warning(paste0("Only ", availableCores, " cores available (", cores, " requested)"))
        cores = availableCores
      }
	#memoryOneCore <- J("java.lang.Runtime")$getRuntime()$totalMemory()*2^-20
    # Get the project name if not given:
    if(missing(projectName)){
      projectName = basename(getProjectDir(baseline))
    }
    cat("Parallel bootstrapping on", cores, "cores:\n")
    # Generate the clusters of time steps:
    cl<-makeCluster(cores)
    # Load the Rstox package and java. Aslo the funciton .initiateBootstrap() runs the baseline model, saves the Java-object in the global environment and returns the abundance by length and individual reported on output. The function bootstrapOneIteration() overwrites the R object baseline if there is a baseline object given in the input:
    ##base <- parLapplyLB(cl, rep(projectName, cores), .initiateBootstrap())
    temp <- parLapplyLB(cl, rep(projectName, cores), .initiateBootstrap)
    # Store the abundance by length and individual in the original model:
    ##base.AbByLength = base[[1]]$AbByLength
    ##base.AbByInd = base[[1]]$AbByInd
    # Bootstrap in parallel:
    out <- parLapplyLB(cl, seq_len(parameters$numIterations), bootstrapOneIteration, assignments=assignments, strata=strata, psuNASC=psuNASC, stratumNASC=stratumNASC, resampledNASC=resampledNASC, startProcess=startProcess, endProcess=endProcess, seedV=seedV)
    # End the parallel bootstrapping:
    stopCluster(cl)
  }
  
  # Order the output from the bootstrapping:
	out <- unlist(out, recursive=FALSE)
  outorder <- matrix(seq_along(out), ncol=2, byrow=TRUE)
  out <- list(AbByLength=out[outorder[,1]], AbByInd=out[outorder[,2]])
  names(out$AbByLength) <- paste0("AbByLength_run", seq_along(out$AbByLength))
  names(out$AbByInd) <- paste0("AbByInd_run", seq_along(out$AbByInd))
  
  # Return:
	list(base.AbByLength=base.AbByLength, AbByLength=out$AbByLength, base.AbByInd=base.AbByInd, AbByInd=out$AbByInd, bootstrapParameters=list(startProcess=startProcess, endProcess=endProcess, numIterations=numIterations, seed=seed, seedV=seedV, cores=cores)) 
}


#*********************************************
#*********************************************
#' Run a bootstrap in StoX
#'
#' Resample (bootstrap) trawl stations based on swept area data and possibly also acoustic data to estimate uncertainty in estimates.
#'
#' @param projectName the name of the StoX project.
#' @param type the type of boostrapping. Currently implemented are "Acoustic" and "SweptArea". Abbreviations "a" and "s" are allowed.
#' @param startProcess Defines start process in the baseline model for the bootstrap routine; TotalLengthDist is default.
#' @param endProcess Defines stop process in the baseline model for the bootstrap routine; AbundanceByPopulationCategory is default.
#' @param numIterations Number of bootstrap replicates.
#' @param seed The seed for the random number generator (used for reproducibility).
#' @param cores an integer giving the number of cores to run the bootstrapping over.
#' @param baseline (optional) a StoX baseline object returned from runBaseline().
#' @param NASCDistr: assumed distribution of mean NASC values, "normal", "lognormal", "gamma", or "weibull" ("normal" is default).
#'
#' @return list with (1) the abundance by length in the orginal model, (2) the abundance by length in the bootstrap run, (3) the abundance by super individuals in the orginal model, (4) the abundance by super individuals in the bootstrap run
#'
#' @examples
#' \dontrun{
#' bootstrap_Acoustic <- runBootstrap("Test_Rstox", type="a", startProcess="TotalLengthDist", endProcess="SuperIndAbundance", numIterations=10, seed=1, cores=1)
#' bootstrap_Acoustic <- runBootstrap("Test_Rstox", type="s", startProcess="TotalLengthDist", endProcess="SuperIndAbundance", numIterations=10, seed=1, cores=1)}
#'
#' @export
#' @rdname runBootstrap
#'
runBootstrap <- function(projectName, type=c("Acoustic", "SweptArea", "ECA"), startProcess="TotalLengthDist", endProcess="SuperIndAbundance", numIterations=5, seed=1, cores=1, baseline=NULL, NASCDistr="normal"){
  # Run the different bootstrap types:
  if(tolower(substr(type[1], 1, 1)) == "a"){
		# Baseline and biotic assignments:
    baseline <- runBaseline(projectName)
    assignments <- getBioticAssignments(baseline=baseline)
    # Acoustic data:
    psuNASC <- getPSUNASC(baseline=baseline)
    stratumNASC <- getNASCDistr(baseline=baseline, psuNASC=psuNASC, NASCDistr=NASCDistr)
    resampledNASC <- getResampledNASCDistr(baseline=baseline, psuNASC=psuNASC, stratumNASC=stratumNASC, parameters=list(numIterations=numIterations, seed=seed))
    # Run bootstrap:
		bootstrap_Acoustic <- bootstrapParallel(projectName=projectName, assignments=assignments, psuNASC=psuNASC, stratumNASC=stratumNASC, resampledNASC=resampledNASC, startProcess=startProcess, endProcess=endProcess, numIterations=numIterations, seed=seed, cores=cores, baseline=baseline)
    # Assign varialbes to the global environment for use in plotting functions. This should be changed to a local Rstox environment in the future:
    assign("psuNASC", psuNASC, envir=getProjectEnv(projectName))
    assign("stratumNASC", stratumNASC, envir=getProjectEnv(projectName))
    assign("resampledNASC", resampledNASC, envir=getProjectEnv(projectName))
    assign("bootstrap_Acoustic", bootstrap_Acoustic, envir=getProjectEnv(projectName))
    # Rerun the baseline to ensure that all processes are run, and return the boostraped data:
    baseline <- runBaseline(projectName)
    bootstrap_Acoustic
  }
  else if(tolower(substr(type[1], 1, 1)) == "s"){
    # Baseline and biotic assignments:
    baseline <- runBaseline(projectName)
    assignments <- getBioticAssignments(baseline=baseline)
    # Run bootstrap:
    bootstrap_SweptArea <- bootstrapParallel(projectName=projectName, assignments=assignments, startProcess=startProcess, endProcess=endProcess, numIterations=numIterations, seed=seed, cores=cores, baseline=baseline)
    # Assign varialbes to the global environment for use in plotting functions. This should be changed to a local Rstox environment in the future:
    assign("bootstrap_SweptArea", bootstrap_SweptArea, envir=getProjectEnv(projectName))
    # Rerun the baseline to ensure that all processes are run, and return the boostraped data:
    baseline <- runBaseline(projectName)
    bootstrap_SweptArea
  }
  else if(tolower(substr(type[1], 1, 1)) == "e"){
    warning("Bootstrapping ECA is not yet avaiable")
  }
  else{
    warning(paste0("Bootstrap type ", type[1], " not recognized"))
  }
}


#*********************************************
#*********************************************
#' (Internal) Initiate Bootstrap
#' 
#' This function is used in parallel bootstrapping to initiate R in several cores.
#' 
#' @param projectName the name of the StoX project.
#'
#' @export
#' @rdname .initiateBootstrap
#'
.initiateBootstrap <- function(projectName){
  # Load Rstox
  library(Rstox)
  # Run the bootstrap:
  baseline <- runBaseline(projectName=projectName, save=FALSE)
  assign("baseline", baseline, envir=.GlobalEnv)
  baseline
  ##list(AbByLength=getDataFrame1(baseline, 'AbundanceByLength'), AbByInd=getDataFrame1(baseline, 'SuperIndAbundance'))
}

#*********************************************
#*********************************************
#' Prepare data from a project baseline run to the ECA model
#' 
#' This function reads data from a baseline run and converts to a list of data used the ECA model in the Reca package.
#' 
#' @param projectName the name of an existing StoX project.
#' @param biotic the process from which the biotic data are extracted, conventionally the BioticCovData process.
#' @param landing the process from which the landing data are extracted, conventionally the LandingCovData process.
#' @param temporal optional definition of the temporal covariate (not yet implemented).
#' @param gearfactor optional definition of the gearfactor covariate (not yet implemented).
#' @param spatial optional definition of the spatial covariate (not yet implemented).
#'
#' @return A reference to the StoX Java baseline object
#'
#' @examples
#' \dontrun{
#' system.time(eca <- baseline2eca("Test_Rstox"))
#' # Show the covariate definitions:
#' eca$resources
#' # Show the eca object:
#' str(eca)}
#'
#' @export
#' @rdname baseline2eca
#'
baseline2eca <- function(projectName, biotic="BioticCovData", landing="LandingCovData", temporal=NULL, gearfactor=NULL, spatial=NULL){
  # Get the relevant output:
  #biotic="BioticCovData"
  #landing="LandingCovData"
  #projectName <- b
  #check.names=TRUE
  #projectName = "ECA_sild_2015"
  #projectName = runBaseline("ECA_sild_2015")
  #ageErrorMatrix <- matrix(c(
  #0.7,0.2,0.1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
  #0.2,0.5,0.2,0.1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
  #0.1,0.2,0.4,0.2,0.1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
  #0,0.1,0.2,0.4,0.2,0.1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
  #0,0,0.1,0.2,0.4,0.2,0.1,0,0,0,0,0,0,0,0,0,0,0,0,0,
  #0,0,0,0.1,0.2,0.4,0.2,0.1,0,0,0,0,0,0,0,0,0,0,0,0,
  #0,0,0,0,0.1,0.2,0.4,0.2,0.1,0,0,0,0,0,0,0,0,0,0,0,
  #0,0,0,0,0,0.1,0.2,0.4,0.2,0.1,0,0,0,0,0,0,0,0,0,0,
  #0,0,0,0,0,0,0.1,0.2,0.4,0.2,0.1,0,0,0,0,0,0,0,0,0,
  #0,0,0,0,0,0,0,0.1,0.2,0.4,0.2,0.1,0,0,0,0,0,0,0,0,
  #0,0,0,0,0,0,0,0,0.1,0.2,0.4,0.2,0.1,0,0,0,0,0,0,0,
  #0,0,0,0,0,0,0,0,0,0.1,0.2,0.4,0.2,0.1,0,0,0,0,0,0,
  #0,0,0,0,0,0,0,0,0,0,0.1,0.2,0.4,0.2,0.1,0,0,0,0,0,
  #0,0,0,0,0,0,0,0,0,0,0,0.1,0.2,0.4,0.2,0.1,0,0,0,0,
  #0,0,0,0,0,0,0,0,0,0,0,0,0.1,0.2,0.4,0.2,0.1,0,0,0,
  #0,0,0,0,0,0,0,0,0,0,0,0,0,0.1,0.2,0.4,0.2,0.1,0,0,
  #0,0,0,0,0,0,0,0,0,0,0,0,0,0,0.1,0.2,0.4,0.2,0.1,0,
  #0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0.1,0.2,0.4,0.2,0.1,
  #0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0.1,0.2,0.5,0.2,
  #0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0.1,0.2,0.7), byrow=TRUE, ncol=20)


  # Function that retreives year, month, day, yearday:
  addYearday <- function(x, datecar="startdate", tz="UTC", format="%d/%m/%Y"){
    x[[datecar]] <- as.POSIXlt(x[[datecar]], tz=tz, format=format)
    if(length(x$year)==0){
      x$year <- x[[datecar]]$year + 1900
    }
    x$month <- x[[datecar]]$mon + 1
    x$monthday <- x[[datecar]]$mday
    x$yearday <- x[[datecar]]$yday + 1
    x
  }
  # Function used for extracting covariate definitions:
  getCovDef <- function(x){
    if(length(grep(",", x[[3]]))){
      x[[3]] = strsplit(x[[3]], ",")
      x[[3]] = lapply(x[[3]], as.numeric)
    }
	#biotic <- as.data.frame(sapply(x, "[", x$CovariateSourceType=="Biotic", drop=FALSE))
    biotic <- x[x$CovariateSourceType=="Biotic", , drop=FALSE]
	#landing <- as.data.frame(lapply(x, "[", x$CovariateSourceType=="Landing", drop=FALSE))
    landing <- x[x$CovariateSourceType=="Landing", , drop=FALSE]
	list(biotic=biotic, landing=landing)
  }
  # Function for removing levels that are not present in the biotic data (the function uses the covDef list, which holds the definitions of the covariates stripped of missing levels in biotic):
  stripLevels <- function(i, x, covDef){
    factor(x[[i]], levels=if(length(covDef[[i]]$biotic)) covDef[[i]]$biotic$Covariate else NULL)
  }
  # Function for adding numeric covariates, both the original and cleaned (stripped of missing levels in biotic) covariates:
  addNumericCovariates <- function(x){
    orig <- lapply(x[covariateNamesFactorOrig], as.numeric)
    names(orig) <- covariateNamesNumericOrig
    cleaned <- lapply(x[covariateNamesFactor], as.numeric)
    names(cleaned) <- covariateNamesNumeric
    cbind(cleaned, orig, x)
  }
  # Function for aggregating landing data in each covariate cell:
  aggregateLanding <- function(x, names, covDef){
    # Replace missing values by "-" to include these levels in the aggregation, and change back to NA at the end. This is because by does not like NAs in the indices. We should find a better way later...:
    x[names][is.na(x[names])] <- "-"
    # Convert to tonnes from the hg definition in the landing data:
    weight_hektogram = by(x$rundvekt, x[,names], sum, na.rm=TRUE)
		weight_tonnes <- weight_hektogram/10000
		covariates <- attributes(weight_tonnes)$dimnames
		suppressWarnings(covariates <- lapply(covariates, as.numeric))
		covariates <- expand.grid(covariates)
		#covariates = expand.grid(attributes(weight_tonnes)$dimnames)
		covariatesFactor <- lapply(seq_along(names), function(xx) covDef[[xx]]$biotic[covariates[[xx]], "Covariate"])
		names(covariatesFactor) <- names(covDef)
		# Aggregate by the covariates:
    out = data.frame(covariates, covariatesFactor, weight_tonnes=c(weight_tonnes))
    # Remove empty cells and order:
    out = out[!is.na(out$weight_tonnes),,drop=FALSE]
    out = out[do.call(order, c(out[names], list(na.last=FALSE))),,drop=FALSE]
    out[out=="-"] <- NA
    rownames(out) <- seq_len(nrow(out))
	out
  }
  
  # Define covariate processes and returned process data:
  covariateProcesses <- c("DefineTemporalLanding", "DefineSeasonLanding", "DefineGearLanding", "DefineSpatialLanding")
  prData <- c("ageerror", "stratumneighbour")
  # Get the baseline output:
  baselineOutput <- getBaseline(projectName, proc=c(biotic, landing), input=FALSE)
  projectInfo <- runBaseline(projectName, info=TRUE)
  
  # Run if both biotic and landing data are present:
  if(all(c(biotic[1], landing[1]) %in% names(baselineOutput))){
    
  
      #####################################
      ##### (1) Get raw landing data: #####
      #####################################
      # (1a) Get the data and convert variable names to lower case:
      landing <- baselineOutput[[landing[1]]]
      names(landing) <- tolower(names(landing))
      landing <- addYearday(landing, datecar="formulardato", tz="UTC", format="%d/%m/%Y")
      #####################################
    
  
    ############################################################
    ##### (2) Get raw biotic data with some modifications: #####
    ############################################################
    # (2a) Get the data and convert variable names to lower case:
    biotic <- baselineOutput[[biotic[1]]]
    names(biotic) <- tolower(names(biotic))
	
	# Detect whether temporal is defined with seasons, and add year and season and remove temporal in the process data:
	if(projectInfo$DefineTemporalLanding$Seasonal=="true"){
		baselineOutput$season <- baselineOutput$temporal
		years <- range(biotic$year, landing$year)
		years <- seq(years[1], years[2])
		baselineOutput$year <- data.frame(CovariateSourceType=rep(c("Biotic","Landing"), each=length(years)), Covariate=rep(years, ,2), Value=rep(years, ,2))
		baselineOutput$temporal <- NULL
	}
  
    # (2b) Define the present covariate names, which are some but not all of the following:
	implementedCovariateNames <- c("temporal", "year", "season", "gearfactor", "spatial")
	implementedCovariateDescriptions <- c("The time covariate, running continuously", "The year covariate, used in conjunction with 'season'", "The season covariate defining seasons throughout a year", "The gear covariate given as groups of gear codes", "The spatial covariate giving polygons or locations")
	implementedCovariateProcesses <- c("DefineTemporalLanding", "DefineTemporalLanding", "DefineTemporalLanding", "DefineGearLanding", "DefineSpatialLanding")
	
	present <- which(implementedCovariateNames %in% names(biotic))
    covariateNames <- implementedCovariateNames[present]
	covariateDescriptions <- implementedCovariateDescriptions[present]
	covariateProcesses <- implementedCovariateProcesses[present]
    covariateNamesFactorOrig <- paste0("Cov", seq_along(covariateNames), "FactorOrig")
    covariateNamesFactor <- paste0("Cov", seq_along(covariateNames), "Factor")
    covariateNamesNumericOrig <- paste0("Cov", seq_along(covariateNames), "NumericOrig")
    covariateNamesNumeric <- paste0("Cov", seq_along(covariateNames), "Numeric")
  
    # (2c) Add yearday, year and month:
    biotic <- addYearday(biotic, datecar="startdate", tz="UTC", format="%d/%m/%Y")
     
    # (2d) Hard code the lengthunits (from the sampling handbook). This must be changed in the future, so that lengthunitmeters is present in the biotic file:
    lengthcode <- 1:7
    lengthmeters <- c(1, 5, 0, 30, 50, 0.5, 0.1)/1000
    biotic$lengthunitmeters <- lengthmeters[match(biotic$lengthunit, lengthcode)]
  
    # (2e) Aggregate by lines without weight, but with equal length:
    duplines = duplicated(biotic[,c("serialno","length","weight")]) & is.na(biotic$age)
    if(any(duplines)){
      frequency = by(biotic$frequency, paste(biotic$serialno, biotic$length), sum)
      biotic = biotic[!duplines,]
      biotic$frequency = frequency
    }
    ############################################################
    
  
    ##########################################################################
    ### (3) Get covariate definitions, convert to factor and change names: ###
    ##########################################################################
    covDefOrig <- lapply(baselineOutput[covariateNames], getCovDef)
    # Add year covariate definitions if present:
    if("year" %in% covariateNames){
      year <- unique(c(landing$year, biotic$year))
      yearBiotic = data.frame(CovariateSourceType="Biotic", Covariate=year, Value=year)
      yearLanding = data.frame(CovariateSourceType="Biotic", Covariate=year, Value=year)
      covDefOrig$year <- list(biotic=yearBiotic, landing=yearLanding)
    }
   
    # Convert the covariates to factors and add all levels to the covariates:
    biotic[covariateNames] <- lapply(covariateNames, function(name) factor(biotic[[name]], levels=covDefOrig[[name]]$biotic$Covariate))
    # Note that landing definitions are used in both landing and landingAgg:
    landing[covariateNames] <- lapply(covariateNames, function(name) factor(landing[[name]], levels=covDefOrig[[name]]$landing$Covariate))
    #landingAgg[covariateNames] <- lapply(covariateNames, function(name) factor(landingAgg[[name]], levels=covDefOrig[[name]]$landing$Covariate))
  
    # Change names to Cov1FactorOrig, ...:
    names(covDefOrig) <- covariateNamesFactorOrig
    presentCovariateNames <- match(covariateNames, names(biotic))
    names(biotic)[presentCovariateNames] <- covariateNamesFactorOrig
    presentCovariateNames <- match(covariateNames, names(landing))
    names(landing)[presentCovariateNames] <- covariateNamesFactorOrig
    ##########################################################################
  
  
    ##########################################################
    ##### (4) Add new covariates with no missing levels: #####
    ##########################################################
    # Get indices of the present levels:
    clean <- function(x){
      x <- as.numeric(unique(x))
      x[!is.na(x)]
    }
    presentBiotic <- lapply(biotic[covariateNamesFactorOrig], clean)
    #presentLanding <- lapply(landing[covariateNamesFactorOrig], clean)
  
    # Pick out the present levels:
    covDef <- covDefOrig
    for(i in seq_along(covariateNamesFactorOrig)){
      covDef[[covariateNamesFactorOrig[i]]] <- lapply(covDef[[covariateNamesFactorOrig[i]]], "[", presentBiotic[[covariateNamesFactorOrig[i]]], TRUE)
    }
    # Rename the elements of covDef:
    names(covDef) <- covariateNamesFactor
	NlevelsOrig <- unlist(lapply(covDefOrig, function(xx) length(xx$biotic$Covariate)))
	Nlevels <- unlist(lapply(covDef, function(xx) length(xx$biotic$Covariate)))
  
    ### Add new covariates to the data: ###
    bioticAdd <- lapply(seq_along(covariateNamesFactorOrig), stripLevels, x=biotic[covariateNamesFactorOrig], covDef=covDef)
    #bioticAdd <- lapply(biotic[covariateNamesFactorOrig], function(xx) as.numeric(factor(xx)))
    names(bioticAdd) <- covariateNamesFactor
    biotic <- cbind(bioticAdd, biotic)
  
    landingAdd <- lapply(seq_along(covariateNamesFactorOrig), stripLevels, x=landing[covariateNamesFactorOrig], covDef=covDef)
    #landingAdd <- lapply(landing[covariateNamesFactorOrig], function(xx) as.numeric(factor(xx)))
    names(landingAdd) <- covariateNamesFactor
    landing <- cbind(landingAdd, landing)
    ##########################################################
  
  
    #################################################
    ##### (5) Add numeric covariates to biotic: #####
    #################################################
    biotic <- addNumericCovariates(biotic)
    landing <- addNumericCovariates(landing)
    #################################################
  
  
    #############################################
    ##### (6) Get aggreagated landing data: #####
    #############################################
    landingAggOrig <- aggregateLanding(landing, covariateNamesNumericOrig, covDef=covDefOrig)
	landingAgg <- aggregateLanding(landing, covariateNamesNumeric, covDef=covDef)
	#############################################
  
  
    ###########################################
    ##### (7) Covariate meta information: #####
    ###########################################
    # Add a data frame with meta information about the covariates:
	covType <- rep(unlist(lapply(covariateProcesses, function(xx) projectInfo[[xx]]$CovariateType)), 4)
	CAR <- rep(NA, length(covType))
	# This process assigns TRUE to CAR only if the parameter 'ConditionalAutoRegression' exists and is equal to the string "true". All other values except empty values (NULL) implies FALSE. If the parameter 'ConditionalAutoRegression' is not present, NA is used:
	temp <- lapply(covariateProcesses, function(xx) projectInfo[[xx]]$ConditionalAutoRegression=="true")
	CAR[unlist(lapply(temp, length))>0] <- unlist(temp)
    # Make sure that CAR is a logical when covType is Random:
	CAR[is.na(CAR) & covType=="Random"] <- FALSE
	covInfo <- data.frame(
		cov=c(covariateNamesNumeric, covariateNamesNumericOrig, covariateNamesFactor, covariateNamesFactorOrig), 
		Nlevels=rep(c(Nlevels, NlevelsOrig), 2), 
		covType=covType, 
		CAR=CAR, 
		name=rep(covariateNames, 4), 
		description=c(outer(covariateDescriptions, c("(numeric, no empty levels)", "(numeric, original with all levels)", "(factor, no empty levels)", "(factor, original with all levels)"), paste)))
	###########################################
	
	
    ################################################
    ##### (8) Fish age vs length-error matrix: #####
    ################################################
    ageErrorData <- baselineOutput[[prData[1]]]
	# Expand the AgeLength data to a sparse matrix:
	maxAge <- max(ageErrorData[,1:2])+1
	ageErrorMatrix <- matrix(0, ncol=maxAge, nrow=maxAge)
	ageErrorMatrix[as.matrix(ageErrorData[,1:2])+1] <- ageErrorData[,3]
	rownames(ageErrorMatrix) <- seq_len(maxAge)-1
	colnames(ageErrorMatrix) <- rownames(ageErrorMatrix)
	################################################
  
  
    ############################################
    ##### (9) Adjacent strata definitions: #####
    ############################################
    stratumNeighbour <- baselineOutput[[prData[2]]]
	#stratumNeighbourList <- vector("list", max(stratumNeighbour[,1]))
	#stratumNeighbourList[as.numeric(stratumNeighbour[,1])] <- lapply(stratumNeighbour[,2], function(xx) as.numeric(unlist(strsplit(xx, ","))))
    stratumNeighbourList <- as.list(stratumNeighbour[,2])
	names(stratumNeighbourList) <- stratumNeighbour[,1]
	stratumNeighbourList <- lapply(stratumNeighbourList, function(xx) as.numeric(unlist(strsplit(xx, ","))))
	#############################################
  
	
	# Return all data in a list
    list(biotic=biotic, landing=landing, landingAgg=landingAgg, landingAggOrig=landingAggOrig, resources=list(covInfo=covInfo, covDef=covDef, covDefOrig=covDefOrig, ageError=ageErrorMatrix, stratumNeighbour=stratumNeighbourList))
  }
  else{
    warning(paste0("The processes ", paste(c(biotic[1], landing[1]), collapse=" and "), "does not exist in the baseline model"))
    invisible(NULL)
  }
}
#'
#' @export
#' @rdname baseline2eca
#' 
baseline2eca_old <- function(projectName, biotic="BioticCovData", landing="LandingCovData", check.names=TRUE, temporal=NULL, gearfactor=NULL, spatial=NULL){
  # Get the relevant output:
  temp <- getBaseline(projectName, proc=c(biotic, landing), input=FALSE)
  
  ##### (1) Get raw biotic data with some modifications: #####
  #biotic="BioticCovData"
  #landing="LandingCovData"
  biotic <- temp[[biotic[1]]]
  names(biotic) <- tolower(names(biotic))
  # Add yearday, year and month:
  biotic$startdate <- as.POSIXlt(biotic$startdate, tz="UTC", format="%d/%m/%Y")
  biotic$year <- biotic$startdate$year + 1900
  biotic$month <- biotic$startdate$mon + 1
  biotic$monthday <- biotic$startdate$mday
  biotic$yearday <- biotic$startdate$yday + 1
  # Aggregate by lines without weight, but with equal length:
  duplines = duplicated(biotic[,c("serialno","length","weight")]) & is.na(biotic$age)
  if(any(duplines)){
    #uniquelines = unique(biotic[,c("serialno", "length")])
  frequency = by(biotic$frequency, paste(biotic$serialno, biotic$length), sum)
  biotic = biotic[!duplines,]
  biotic$frequency = frequency
  }
  
  ##### (2) Get raw landing data: #####
  landing <- temp[[landing[1]]]
  names(landing) <- tolower(names(landing))
  # Set missing values to 0:
  needsNA = which(colSums(landing=="-")>0)
  landing[landing=="-"] = 0
  # ... and convert to numeric:
  for(i in seq_along(needsNA)){
      landing[[i]] = as.numeric(landing[[i]])
  }
  
  # Change the covariates to having values 1, ..., number of levels, after replacing "-" (missing values) by 0:
  allTemporal <- sort(unique(c(biotic$temporal, landing$temporal)))
  allGearfactor <- sort(unique(c(biotic$gearfactor, landing$gearfactor)))
  allSpatial <- sort(unique(c(biotic$spatial, landing$spatial)))
  newTemporal <- seq_along(allTemporal)
  newGearfactor <- seq_along(allGearfactor)
  newSpatial <- seq_along(allSpatial)
  # Add successive covariates as the first columns:
  covNames = c("temporal", "gearfactor", "spatial")
  names(biotic)[names(biotic) %in% covNames] <- paste0(covNames, 0)
  names(landing)[names(landing) %in% covNames] <- paste0(covNames, 0)
  biotic <- cbind(
    temporal=match(biotic$temporal, allTemporal), 
    gearfactor=match(biotic$gearfactor, allGearfactor), 
    spatial=match(biotic$spatial, allSpatial), 
    biotic)
  landing <- cbind(
    temporal=match(landing$temporal, allTemporal), 
    gearfactor=match(landing$gearfactor, allGearfactor), 
    spatial=match(landing$spatial, allSpatial), 
    landing)

  ##### (3) Get aggreagated landing data: #####
  sumweight = by(landing$rundvekt, landing[,c("temporal", "gearfactor", "spatial")], sum)
  covariates = expand.grid(attributes(sumweight)$dimnames)
  #covariates0 = lapply(covariates, function(xx) as.numeric(levels(xx))[xx])
  #names(covariates0) = paste0(names(covariates0), 0)
  covariates = lapply(covariates, as.numeric)
  # Aggregate by the covariates:
  #landingAgg = data.frame(covariates, weight=c(sumweight), covariates0)
  landingAgg = data.frame(covariates, weight=c(sumweight))
  # Remove empty cells and order:
  landingAgg = landingAgg[!is.na(landingAgg$weight),,drop=FALSE]
  landingAgg = landingAgg[order(landingAgg$temporal, landingAgg$gearfactor, landingAgg$spatial),,drop=FALSE]
  # Add the original covariates:
  landingAgg = cbind(landingAgg, 
    temporal0=allTemporal[landingAgg$temporal],
    gearfactor0=allGearfactor[landingAgg$gearfactor],
    spatial0=allSpatial[landingAgg$spatial])
  
  # (4) Get covariate definitions:
  # Temporal:
  cov.temp.biotic <- lapply(temp$temporal, "[", temp$temporal$CovariateSourceType=="Biotic")
  cov.temp.landing <- lapply(temp$temporal, "[", temp$temporal$CovariateSourceType=="Landing")
  # Gear:
  temp$gear[[3]] = strsplit(temp$gear[[3]], ",")
  temp$gear[[3]] = lapply(temp$gear[[3]], as.numeric)
  cov.gear.biotic <- lapply(temp$gear, "[", temp$gear$CovariateSourceType=="Biotic")
  cov.gear.landing <- lapply(temp$gear, "[", temp$gear$CovariateSourceType=="Landing")
  # Spatial
  cov.spat.biotic <- lapply(temp$spat, "[", temp$spat$CovariateSourceType=="Biotic")
  cov.spat.landing <- lapply(temp$spat, "[", temp$spat$CovariateSourceType=="Landing")
  # Check whether the biotic and landing definitions differ:
  if(!identical(cov.temp.biotic$value, cov.temp.landing$value)){
    warning("Temporal covariate definitions differ for biotic and landing data")
  }
  if(!identical(cov.spat.biotic$value, cov.spat.landing$value)){
    warning("Spatial covariate definitions differ for biotic and landing data")
  }
  # Add new successive covariates in to the definitions:
  cov.temp.biotic$Covariate0 <- cov.temp.biotic$Covariate
  cov.temp.landing$Covariate0 <- cov.temp.landing$Covariate
  cov.gear.biotic$Covariate0 <- cov.gear.biotic$Covariate
  cov.gear.landing$Covariate0 <- cov.gear.landing$Covariate
  cov.spat.biotic$Covariate0 <- cov.spat.biotic$Covariate
  cov.spat.landing$Covariate0 <- cov.spat.landing$Covariate
  # Insert the new covariates:
  cov.temp.biotic$Covariate <- match(cov.temp.biotic$Covariate, allTemporal)
  cov.temp.landing$Covariate <- match(cov.temp.landing$Covariate, allTemporal)
  cov.gear.biotic$Covariate <- match(cov.gear.biotic$Covariate, allGearfactor)
  cov.gear.landing$Covariate <- match(cov.gear.landing$Covariate, allGearfactor)
  cov.spat.biotic$Covariate <- match(cov.spat.biotic$Covariate, allSpatial)
  cov.spat.landing$Covariate <- match(cov.spat.landing$Covariate, allSpatial)
  
  resources <- list(
    cov.temp.biotic=as.data.frame(cov.temp.biotic),
    cov.temp.landing=as.data.frame(cov.temp.landing),
    cov.gear.biotic=cov.gear.biotic,
    cov.gear.landing=cov.gear.landing,
    cov.spat.biotic=as.data.frame(cov.spat.biotic),
    cov.spat.landing=as.data.frame(cov.spat.landing))
  
  # Return all data in a list
  list(biotic=biotic, landing=landing, landingAgg=landingAgg, resources=resources)
}